import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // checkout8oZ (1:8071)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupbk9mEbh (XTz1kcQbLtMgtVDQ54bk9m)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              height: 115*fem,
              child: Stack(
                children: [
                  Positioned(
                    // statusbarMgK (1:8145)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 115*fem,
                        child: Image.asset(
                          'assets/page-1/images/status-bar.png',
                          width: 375*fem,
                          height: 115*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // checkoutShm (1:8199)
                    left: 148*fem,
                    top: 53*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 42*fem,
                        child: Text(
                          'Checkout',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Montserrat',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 2.625*ffem/fem,
                            letterSpacing: -0.2399999946*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupg5hqhdh (XTz1rXQQVU3A1oL4chG5hq)
              width: double.infinity,
              height: 681*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29931SLP (1:8072)
                    left: 129*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 139*fem,
                        height: 202*fem,
                        child: Image.asset(
                          'assets/page-1/images/frame-29931.png',
                          width: 139*fem,
                          height: 202*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1016TWP (1:8140)
                    left: 0*fem,
                    top: 567*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 114*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // homeindicatorZ3d (I1:8141;5:3093)
                    left: 121*fem,
                    top: 668*fem,
                    child: Align(
                      child: SizedBox(
                        width: 134*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // buttonroR (1:8142)
                    left: 16*fem,
                    top: 567*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 343*fem,
                        height: 48*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff4b0000),
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Center(
                          child: Text(
                            'PAY NOW',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.5*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group17u11 (1:8157)
                    left: 0*fem,
                    top: 19*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(23*fem, 23*fem, 24*fem, 12.51*fem),
                      width: 374*fem,
                      height: 550*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(16*fem),
                          topRight: Radius.circular(16*fem),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x28212121),
                            offset: Offset(0*fem, -4*fem),
                            blurRadius: 12*fem,
                          ),
                        ],
                      ),
                      child: Container(
                        // group178eT (1:8159)
                        width: double.infinity,
                        height: double.infinity,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // autogroupubnoGkf (XTz4ccUKuSVCPJA8xUuBNo)
                              padding: EdgeInsets.fromLTRB(35.77*fem, 0*fem, 35.77*fem, 24.74*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroup26mmzRm (XTz2URYFoFCNjjkBWD26mM)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 38.06*fem),
                                    padding: EdgeInsets.fromLTRB(28.61*fem, 19.03*fem, 20.86*fem, 16.68*fem),
                                    width: double.infinity,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(20*fem),
                                      image: DecorationImage (
                                        fit: BoxFit.cover,
                                        image: AssetImage (
                                          'assets/page-1/images/rectangle-bg.png',
                                        ),
                                      ),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Color(0x0b000000),
                                          offset: Offset(0*fem, 5.3439836502*fem),
                                          blurRadius: 1.6575100422*fem,
                                        ),
                                        BoxShadow(
                                          color: Color(0x10000000),
                                          offset: Offset(0*fem, 14.775431633*fem),
                                          blurRadius: 6.3981170654*fem,
                                        ),
                                        BoxShadow(
                                          color: Color(0x14a854b6),
                                          offset: Offset(0*fem, 35.5735473633*fem),
                                          blurRadius: 10*fem,
                                        ),
                                        BoxShadow(
                                          color: Color(0x3fe27747),
                                          offset: Offset(0*fem, 50*fem),
                                          blurRadius: 50*fem,
                                        ),
                                      ],
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogroupantyYbh (XTz2garfEF23N1kpHeaNTy)
                                          margin: EdgeInsets.fromLTRB(1.02*fem, 0*fem, 0*fem, 18.08*fem),
                                          width: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group14gC7 (1:8163)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0.95*fem, 68.61*fem, 0*fem),
                                                width: 43.79*fem,
                                                height: 28.55*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-14.png',
                                                  width: 43.79*fem,
                                                  height: 28.55*fem,
                                                ),
                                              ),
                                              Container(
                                                // group15ANB (1:8171)
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.end,
                                                  children: [
                                                    Container(
                                                      // vectorKF5 (1:8172)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.13*fem, 0.87*fem),
                                                      width: 20.44*fem,
                                                      height: 19.03*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/vector.png',
                                                        width: 20.44*fem,
                                                        height: 19.03*fem,
                                                      ),
                                                    ),
                                                    Text(
                                                      // wpaymeEN3 (1:8173)
                                                      'WPayme',
                                                      style: SafeGoogleFont (
                                                        'Solway',
                                                        fontSize: 15*ffem,
                                                        fontWeight: FontWeight.w700,
                                                        height: 1.2*ffem/fem,
                                                        color: Color(0xbfffffff),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // xYw (1:8174)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10.95*fem, 6.74*fem),
                                          child: Text(
                                            '4563     6748     3754     1773',
                                            style: SafeGoogleFont (
                                              'Montserrat',
                                              fontSize: 14*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2175*ffem/fem,
                                              color: Color(0xb2ffffff),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // autogroupm5tbTEo (XTz2pfTXkkhFv4SxqRm5tB)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 3.15*fem, 0*fem),
                                          width: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              Container(
                                                // P8T (1:8175)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 78.52*fem, 0*fem),
                                                child: Text(
                                                  '\$ 50.00',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 23*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2175*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // autogroup52yxVxB (XTz2v5UBCagdUttfqo52YX)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1.97*fem),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // group16Eum (1:8176)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.95*fem),
                                                      width: 38.32*fem,
                                                      height: 23.79*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-16.png',
                                                        width: 38.32*fem,
                                                        height: 23.79*fem,
                                                      ),
                                                    ),
                                                    Container(
                                                      // mastercardAHd (1:8179)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1.28*fem, 0*fem),
                                                      child: Text(
                                                        'Mastercard',
                                                        style: SafeGoogleFont (
                                                          'Montserrat',
                                                          fontSize: 6*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.2175*ffem/fem,
                                                          color: Color(0xffffffff),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupmfrhg15 (XTz3CpVHEpLqjstkQAMFRH)
                                    margin: EdgeInsets.fromLTRB(19.42*fem, 0*fem, 60.29*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Container(
                                          // transactionCk7 (1:8183)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 38.41*fem, 1.64*fem),
                                          child: Text(
                                            'Transaction',
                                            style: SafeGoogleFont (
                                              'Montserrat',
                                              fontSize: 20*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2175*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // biarrowdownleftsquarefill7MH (1:8160)
                                          width: 16.35*fem,
                                          height: 15.23*fem,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupjy6pSuM (XTz3LUwBM2weKrrmLDjy6P)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28.23*fem),
                              padding: EdgeInsets.fromLTRB(4.09*fem, 2.85*fem, 59*fem, 2.85*fem),
                              width: double.infinity,
                              height: 47.58*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffe6e6e6),
                                borderRadius: BorderRadius.circular(15*fem),
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupf4ddjNf (XTz3WJz8qBYCLaQGGRf4dd)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44.41*fem, 0*fem),
                                    width: 163.5*fem,
                                    height: double.infinity,
                                    decoration: BoxDecoration (
                                      color: Color(0xff000000),
                                      borderRadius: BorderRadius.circular(15*fem),
                                    ),
                                    child: Center(
                                      child: Text(
                                        'Confirm',
                                        style: SafeGoogleFont (
                                          'Montserrat',
                                          fontSize: 15*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1.2175*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // historyzZV (1:8185)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.95*fem),
                                    child: Text(
                                      'History',
                                      style: SafeGoogleFont (
                                        'Montserrat',
                                        fontSize: 15*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.2175*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // cardnumberX3d (1:8186)
                              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 8.15*fem),
                              child: Text(
                                'Card number',
                                style: SafeGoogleFont (
                                  'Montserrat',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2175*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                            Container(
                              // autogroupy1hyYjR (XTz3biznH1XZuQqyGny1Hy)
                              width: double.infinity,
                              height: 38.06*fem,
                              decoration: BoxDecoration (
                                color: Color(0xffe6e6e6),
                                borderRadius: BorderRadius.circular(15*fem),
                              ),
                              child: Center(
                                child: Text(
                                  '4563 - 6748 - 3754 - 1773                     EXP 02/27      ',
                                  style: SafeGoogleFont (
                                    'Montserrat',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2175*ffem/fem,
                                    color: Color(0xbf000000),
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              // autogroupayjfEcF (XTz4xBk3bH4cpKJJuMAyJf)
                              padding: EdgeInsets.fromLTRB(0*fem, 1.9*fem, 0*fem, 0*fem),
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // autogroupdlr3y43 (XTz3hdzbRbD32ixdpRdLr3)
                                    margin: EdgeInsets.fromLTRB(15.33*fem, 0*fem, 46.17*fem, 35.53*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Container(
                                          // teenyiconsticksmallsolidHaX (1:8161)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8.17*fem, 4.44*fem),
                                          width: 15.33*fem,
                                          height: 14.27*fem,
                                        ),
                                        Text(
                                          // pleaseenterthewalletidordestin (1:8191)
                                          'Please enter the Wallet ID or Destination email',
                                          style: SafeGoogleFont (
                                            'Montserrat',
                                            fontSize: 10*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.2175*ffem/fem,
                                            color: Color(0x7f000000),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupksb5Xzf (XTz3pDdxqqoxuLdukQksb5)
                                    margin: EdgeInsets.fromLTRB(4.09*fem, 0*fem, 109.33*fem, 10.69*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // amountf5H (1:8187)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 116.59*fem, 0*fem),
                                          child: Text(
                                            'Amount',
                                            style: SafeGoogleFont (
                                              'Montserrat',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2175*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                        Text(
                                          // reasonyLs (1:8194)
                                          'Reason',
                                          style: SafeGoogleFont (
                                            'Montserrat',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.2175*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroup1cdmvG7 (XTz3vxwiq1eFxnCqXV1CdM)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.13*fem, 9.88*fem),
                                    width: double.infinity,
                                    height: 38.06*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogroupdwp9eC7 (XTz45o2LuercrYQRPADWP9)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 14.31*fem, 0*fem),
                                          padding: EdgeInsets.fromLTRB(15.33*fem, 11.42*fem, 14.31*fem, 11.64*fem),
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xffefefef),
                                            borderRadius: BorderRadius.circular(15*fem),
                                          ),
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // LKq (1:8193)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 70.47*fem, 0*fem),
                                                child: Text(
                                                  '\$ 50.00',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2175*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // autogroup4frxfN7 (XTz4AYPS5ovXg5HX1B4FrX)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0.23*fem, 0*fem, 0*fem),
                                                width: 8.18*fem,
                                                height: 13.32*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/auto-group-4frx.png',
                                                  width: 8.18*fem,
                                                  height: 13.32*fem,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // autogroupybvhmvw (XTz4Hd1yCpDZ7AdkURYBVH)
                                          padding: EdgeInsets.fromLTRB(15.41*fem, 10.95*fem, 15.41*fem, 12.12*fem),
                                          width: 153.28*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xffe8e8e8),
                                            borderRadius: BorderRadius.circular(15*fem),
                                          ),
                                          child: Center(
                                            // trainingsessionsVrw (1:8196)
                                            child: SizedBox(
                                              child: Container(
                                                constraints: BoxConstraints (
                                                  maxWidth: 103*fem,
                                                ),
                                                child: Text(
                                                  'Training session s',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2175*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroup8uupBzf (XTz4ThZWYLf9u81jBG8UUP)
                                    margin: EdgeInsets.fromLTRB(15.33*fem, 0*fem, 14*fem, 0*fem),
                                    width: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // commission5XYj (1:8188)
                                          margin: EdgeInsets.fromLTRB(0*fem, 2.49*fem, 50.67*fem, 0*fem),
                                          child: Text(
                                            'Commission              \$5',
                                            style: SafeGoogleFont (
                                              'Montserrat',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2175*ffem/fem,
                                              color: Color(0xbf000000),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // total50003GB (1:8189)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2.49*fem),
                                          child: Text(
                                            'Total                          \$50.00',
                                            style: SafeGoogleFont (
                                              'Montserrat',
                                              fontSize: 10*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.2175*ffem/fem,
                                              color: Color(0xbf000000),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // homeog3 (1:2955)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupu8asgE3 (XTxsHwK7aEgdQDaqV1u8as)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-21-64w.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // statusbariphonexornewerYX9 (1:4496)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: 375*fem,
                    height: 44*fem,
                    child: Image.asset(
                      'assets/page-1/images/status-bar-iphone-x-or-newer-gT9.png',
                      width: 375*fem,
                      height: 44*fem,
                    ),
                  ),
                  Container(
                    // autogroupxbp32SK (XTxsXWkpq2xu7WfWxhxBp3)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    height: 48*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // group29836LC7 (1:4535)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 149*fem, 0*fem),
                          width: 170*fem,
                          height: double.infinity,
                          child: Stack(
                            children: [
                              Positioned(
                                // group29834rgF (1:4536)
                                left: 0*fem,
                                top: 0*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Container(
                                    width: 122.93*fem,
                                    height: 48*fem,
                                    child: Align(
                                      // image18mYK (1:4537)
                                      alignment: Alignment.centerLeft,
                                      child: SizedBox(
                                        width: 41*fem,
                                        height: 48*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/image-18-W71.png',
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // frame29777hRy (1:4539)
                                left: 49*fem,
                                top: 4.5*fem,
                                child: Container(
                                  width: 121*fem,
                                  height: 39*fem,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame297791hZ (1:4541)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.5*fem, 0*fem),
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // location8GP (1:4542)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.5*fem, 0*fem),
                                              child: Text(
                                                'Location',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // keyboardarrowdown1D2w (1:4543)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0.44*fem, 0*fem, 0*fem),
                                              width: 9*fem,
                                              height: 5.56*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/keyboardarrowdown-1-vAj.png',
                                                width: 9*fem,
                                                height: 5.56*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Text(
                                        // octobarstreet1078K (1:4546)
                                        '10 Octobar street 10,',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // ico24alertsnotificationsEij (1:4497)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/ico-24-alerts-notifications-gCo.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup9wawMHZ (XTxswFaGhpJTDB514n9wAw)
              width: 2234*fem,
              height: 756*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29798tYP (1:2956)
                    left: 16*fem,
                    top: 0*fem,
                    child: Container(
                      width: 2218*fem,
                      height: 756*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // frame29783cjH (1:2957)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                            width: 343*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // whatsportyouarelookingforkab (1:2958)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                  child: Text(
                                    'What Sport You are Looking For...',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // frame29797eR5 (1:2959)
                                  width: double.infinity,
                                  height: 115*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // frame29796CBh (1:2960)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame297828b9 (1:2961)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                              child: TextButton(
                                                onPressed: () {},
                                                style: TextButton.styleFrom (
                                                  padding: EdgeInsets.zero,
                                                ),
                                                child: Container(
                                                  height: double.infinity,
                                                  child: Column(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // group29793Sbq (1:2962)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                        width: 104*fem,
                                                        height: 90*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/group-29793-Egw.png',
                                                          width: 104*fem,
                                                          height: 90*fem,
                                                        ),
                                                      ),
                                                      Text(
                                                        // trainerYum (1:2988)
                                                        'Trainer',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 14*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame29781gWB (1:2989)
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // group29782qP5 (1:2990)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: 104*fem,
                                                    height: 90*fem,
                                                    child: Image.asset(
                                                      'assets/page-1/images/group-29782-1HZ.png',
                                                      width: 104*fem,
                                                      height: 90*fem,
                                                    ),
                                                  ),
                                                  Text(
                                                    // fieldsZ4B (1:3019)
                                                    'Fields',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 14*ffem,
                                                      fontWeight: FontWeight.w500,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame297836Zu (1:3020)
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // group29794pko (1:3021)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                              width: 103*fem,
                                              height: 90*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/group-29794-xPq.png',
                                                width: 103*fem,
                                                height: 90*fem,
                                              ),
                                            ),
                                            Container(
                                              // academyXv7 (1:3035)
                                              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                                              child: Text(
                                                'Academy ',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // frame29795SGP (1:3036)
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupemjpnLF (XTxtY4ubKdToDkCNxDemJP)
                                  padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame29794Kb5 (1:3037)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                        width: 1354*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // nearbytrainer4Hm (1:3038)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                              child: Text(
                                                'Near by Trainer',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame29792yfd (1:3039)
                                              width: double.infinity,
                                              height: 169*fem,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  TextButton(
                                                    // userphotoW9m (1:3040)
                                                    onPressed: () {},
                                                    style: TextButton.styleFrom (
                                                      padding: EdgeInsets.zero,
                                                    ),
                                                    child: Container(
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupbde7RnX (XTxu5yA71P6FTsEqXcbdE7)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // group29822xXZ (1:3041)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Container(
                                                                    width: 100*fem,
                                                                    height: 139*fem,
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          // ellipse800tAK (1:3042)
                                                                          left: 0*fem,
                                                                          top: 0*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 138.84*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-800-Cxo.png',
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // ellipse801oHH (1:3043)
                                                                          left: 0*fem,
                                                                          top: 102*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 37*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-801-c1M.png',
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // jennywilson84f (1:3044)
                                                                          left: 16*fem,
                                                                          top: 110*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 68*fem,
                                                                              height: 15*fem,
                                                                              child: Text(
                                                                                'Jenny Wilson',
                                                                                style: SafeGoogleFont (
                                                                                  'Poppins',
                                                                                  fontSize: 10*ffem,
                                                                                  fontWeight: FontWeight.w600,
                                                                                  height: 1.5*ffem/fem,
                                                                                  color: Color(0xffffffff),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group297792A3 (1:3045)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-27h.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800qtB (1:3108)
                                                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                                                            padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // starpurple5001kVM (1:3109)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-1-cuu.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5005sK5 (1:3112)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-5-DnP.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5006bF5 (1:3115)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-6-dMq.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5007Wsq (1:3118)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-7-H4b.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starborder1SWb (1:3121)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starborder-1-Jo9.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotoZLK (1:3124)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupkkt9K4b (XTxuXsacG6RYzGDodqKkT9)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse800EST (1:3125)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-w2o.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801kQo (1:3126)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-7Ku.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonULo (1:3127)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779BW7 (1:3131)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-ysM.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame298008pf (1:3194)
                                                          margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                                                          padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // starpurple5001K8T (1:3195)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-1-KTd.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starpurple5005pqu (1:3198)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-5-BGb.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starpurple5006wvX (1:3201)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-6-rYw.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starpurple5007FwD (1:3204)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-7-GbH.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starborder1ysD (1:3207)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starborder-1-QFy.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotoJ8o (1:3210)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupxvp3Sko (XTxuwcQ48sm75vdHjuXVp3)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse8009QK (1:3211)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-yhh.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801rpX (1:3212)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-VQ3.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonyeF (1:3213)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779UL7 (1:3217)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-fxj.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800tej (1:3280)
                                                          margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                                                          padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // starpurple5001zSs (1:3281)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-1-HVR.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starpurple5005hMH (1:3284)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-5-QDm.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starpurple5006cj9 (1:3287)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-6-sC3.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starpurple5007kKZ (1:3290)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starpurple500-7-vzb.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 6.67*fem,
                                                              ),
                                                              Container(
                                                                // starborder1gDD (1:3293)
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/starborder-1-biP.png',
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  TextButton(
                                                    // userphotoc6s (1:3296)
                                                    onPressed: () {},
                                                    style: TextButton.styleFrom (
                                                      padding: EdgeInsets.zero,
                                                    ),
                                                    child: Container(
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupohju8qu (XTxvHBfmpiLXWwmTgmoHju)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // group298224jZ (1:3297)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Container(
                                                                    width: 100*fem,
                                                                    height: 139*fem,
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          // ellipse800C55 (1:3298)
                                                                          left: 0*fem,
                                                                          top: 0*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 138.84*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-800-XFu.png',
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // ellipse8017Sw (1:3299)
                                                                          left: 0*fem,
                                                                          top: 102*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 37*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-801-sgb.png',
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // jennywilsoneBy (1:3300)
                                                                          left: 16*fem,
                                                                          top: 110*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 68*fem,
                                                                              height: 15*fem,
                                                                              child: Text(
                                                                                'Jenny Wilson',
                                                                                style: SafeGoogleFont (
                                                                                  'Poppins',
                                                                                  fontSize: 10*ffem,
                                                                                  fontWeight: FontWeight.w600,
                                                                                  height: 1.5*ffem/fem,
                                                                                  color: Color(0xffffffff),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group297799eX (1:3301)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-8Mm.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800x6B (1:3364)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-ifq.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotoG6s (1:3380)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupo2qubuq (XTxvhLeC7nkVafu5QZo2qu)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse800895 (1:3381)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-nBy.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801Exo (1:3382)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-Vrf.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonMnX (1:3383)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779G8o (1:3387)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-KJX.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800Ukf (1:3450)
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/frame-29800-hUK.png',
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotoaoh (1:3466)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupmbckjRh (XTxw6k8rrjdKJgXFpTmBcK)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse8003hH (1:3467)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-CHM.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801Mxs (1:3468)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-3jd.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonswD (1:3469)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779zF9 (1:3473)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-vPR.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800oyH (1:3536)
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/frame-29800-dcs.png',
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  TextButton(
                                                    // userphotoX8b (1:3552)
                                                    onPressed: () {},
                                                    style: TextButton.styleFrom (
                                                      padding: EdgeInsets.zero,
                                                    ),
                                                    child: Container(
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroup9mqrG6B (XTxwSV4y7VS6vXZ5cR9mqR)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // group29822naK (1:3553)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Container(
                                                                    width: 100*fem,
                                                                    height: 139*fem,
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          // ellipse800uuq (1:3554)
                                                                          left: 0*fem,
                                                                          top: 0*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 138.84*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-800-Etw.png',
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // ellipse801ESK (1:3555)
                                                                          left: 0*fem,
                                                                          top: 102*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 37*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-801-ohR.png',
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // jennywilsonxdD (1:3556)
                                                                          left: 16*fem,
                                                                          top: 110*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 68*fem,
                                                                              height: 15*fem,
                                                                              child: Text(
                                                                                'Jenny Wilson',
                                                                                style: SafeGoogleFont (
                                                                                  'Poppins',
                                                                                  fontSize: 10*ffem,
                                                                                  fontWeight: FontWeight.w600,
                                                                                  height: 1.5*ffem/fem,
                                                                                  color: Color(0xffffffff),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group297794RM (1:3557)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-kLo.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800fg3 (1:3620)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-rBR.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotoxv3 (1:3636)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupyxy1iPR (XTxwpyRVjPYR7znAsKyXy1)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse800Ecf (1:3637)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-391.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801YdM (1:3638)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-4iB.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonF1y (1:3639)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779jC3 (1:3643)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-zaK.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800Kvw (1:3706)
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/frame-29800-UAj.png',
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphoto2qM (1:3722)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupuvytZaP (XTxxDiGcCfVn6hqjtsUVYT)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse800Gjh (1:3723)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-MX5.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801aVV (1:3724)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-nX1.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonuXm (1:3725)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779bvP (1:3729)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-3dy.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800Dwm (1:3792)
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/frame-29800-CD5.png',
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  TextButton(
                                                    // userphotoYDM (1:3808)
                                                    onPressed: () {},
                                                    style: TextButton.styleFrom (
                                                      padding: EdgeInsets.zero,
                                                    ),
                                                    child: Container(
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupzsz1Gv3 (XTxxaTB3rvgkqWDUmMZsZ1)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // group2982216w (1:3809)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Container(
                                                                    width: 100*fem,
                                                                    height: 139*fem,
                                                                    child: Stack(
                                                                      children: [
                                                                        Positioned(
                                                                          // ellipse8007vf (1:3810)
                                                                          left: 0*fem,
                                                                          top: 0*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 138.84*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-800-JYo.png',
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // ellipse801dPD (1:3811)
                                                                          left: 0*fem,
                                                                          top: 102*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 100*fem,
                                                                              height: 37*fem,
                                                                              child: Image.asset(
                                                                                'assets/page-1/images/ellipse-801-NP1.png',
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                        Positioned(
                                                                          // jennywilsonMa7 (1:3812)
                                                                          left: 16*fem,
                                                                          top: 110*fem,
                                                                          child: Align(
                                                                            child: SizedBox(
                                                                              width: 68*fem,
                                                                              height: 15*fem,
                                                                              child: Text(
                                                                                'Jenny Wilson',
                                                                                style: SafeGoogleFont (
                                                                                  'Poppins',
                                                                                  fontSize: 10*ffem,
                                                                                  fontWeight: FontWeight.w600,
                                                                                  height: 1.5*ffem/fem,
                                                                                  color: Color(0xffffffff),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ],
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779s2f (1:3813)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-GSB.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame298005Pd (1:3876)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-hHR.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotoyzo (1:3892)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupjriwXWX (XTxxyXLwU36rBs4MV5JRiw)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse8003zf (1:3893)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-g1m.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse801Zy1 (1:3894)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-9SX.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilsonVLs (1:3895)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779oMZ (1:3899)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-eL7.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800ESs (1:3962)
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/frame-29800-4dD.png',
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 14*fem,
                                                  ),
                                                  Container(
                                                    // userphotowcB (1:3978)
                                                    width: 100*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroup6bwwVNo (XTxyMGDiXog23cn1S66bWw)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 145*fem,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                // ellipse8001c3 (1:3979)
                                                                left: 0*fem,
                                                                top: 0*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 138.84*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-800-xZu.png',
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // ellipse8018As (1:3980)
                                                                left: 0*fem,
                                                                top: 102*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 100*fem,
                                                                    height: 37*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/ellipse-801-d35.png',
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // jennywilson44X (1:3981)
                                                                left: 16*fem,
                                                                top: 110*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 68*fem,
                                                                    height: 15*fem,
                                                                    child: Text(
                                                                      'Jenny Wilson',
                                                                      style: SafeGoogleFont (
                                                                        'Poppins',
                                                                        fontSize: 10*ffem,
                                                                        fontWeight: FontWeight.w600,
                                                                        height: 1.5*ffem/fem,
                                                                        color: Color(0xffffffff),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                              Positioned(
                                                                // group29779Z1H (1:3985)
                                                                left: 43*fem,
                                                                top: 128.8542480469*fem,
                                                                child: Align(
                                                                  child: SizedBox(
                                                                    width: 14*fem,
                                                                    height: 16.15*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/group-29779-VNf.png',
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                    ),
                                                                  ),
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                        Container(
                                                          // frame29800NUX (1:4048)
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/frame-29800-tRM.png',
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Container(
                                        // frame29787VJF (1:4064)
                                        width: 1772*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Container(
                                              // nearbyfieldRxb (1:4065)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                              child: Text(
                                                'Near by Field',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // frame297839dh (1:4066)
                                              width: double.infinity,
                                              height: 126*fem,
                                              child: Row(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                children: [
                                                  Container(
                                                    // fieldphotot5V (1:4067)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupngwh2hV (XTxyr5j2iaYDLTqtrMNgwh)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-3FM.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29831KAo (1:4073)
                                                          width: double.infinity,
                                                          height: 18*fem,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballTXu (1:4074)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame29800yFM (1:4075)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                                                                padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                                height: double.infinity,
                                                                child: Row(
                                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                                  children: [
                                                                    Container(
                                                                      // starpurple50015JP (1:4076)
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/starpurple500-1-shH.png',
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      width: 6.67*fem,
                                                                    ),
                                                                    Container(
                                                                      // starpurple5005BcK (1:4079)
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/starpurple500-5-eaK.png',
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      width: 6.67*fem,
                                                                    ),
                                                                    Container(
                                                                      // starpurple5006W8o (1:4082)
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/starpurple500-6-aKZ.png',
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      width: 6.67*fem,
                                                                    ),
                                                                    Container(
                                                                      // starpurple5007dDR (1:4085)
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/starpurple500-7-oD1.png',
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                      ),
                                                                    ),
                                                                    SizedBox(
                                                                      width: 6.67*fem,
                                                                    ),
                                                                    Container(
                                                                      // starborder1MQK (1:4088)
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/starborder-1-tBH.png',
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphotorrs (1:4091)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogrouptwqwQdV (XTxz9A4utef9y6dH6ttWQw)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-JVd.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823727 (1:4096)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballFe7 (1:4097)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame29800B1y (1:4098)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-Hyq.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphoto57M (1:4114)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupsmafpKq (XTxzQ9dvyFQ2mQn1GqSMAf)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-XLs.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823us5 (1:4119)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballTtb (1:4120)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame29800yc3 (1:4121)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-Zjm.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphoto5uy (1:4137)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogrouptp7mq8T (XTxzforWKX4NK2VLq8TP7M)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-xHM.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823KpK (1:4142)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // football5Yb (1:4143)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame29800z9m (1:4144)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-ahV.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphotoHef (1:4160)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupbcqvEK1 (XTxzxU3R5J6tybYbTxBCqV)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-TXd.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823jWf (1:4165)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballtPZ (1:4166)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame29800DRq (1:4167)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-zS3.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphotow6w (1:4183)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogroupj3bdt2B (XTy1DTcS9tqmmuhKdtj3bD)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-519.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823aQo (1:4188)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballX59 (1:4189)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame2980033V (1:4190)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-XFm.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphotoM4B (1:4206)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogrouprsq9h83 (XTy1VHVQ55jUWMJK3Grsq9)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-bc3.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823uju (1:4211)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballU2K (1:4212)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame29800BSX (1:4213)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-uc3.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  SizedBox(
                                                    width: 12*fem,
                                                  ),
                                                  Container(
                                                    // fieldphotoh9y (1:4229)
                                                    width: 211*fem,
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // autogrouphvorSdM (XTy1jH65kB6ABi788ghvoR)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                          width: double.infinity,
                                                          height: 100*fem,
                                                          decoration: BoxDecoration (
                                                            border: Border.all(color: Color(0xff4b0000)),
                                                            borderRadius: BorderRadius.circular(8*fem),
                                                            image: DecorationImage (
                                                              fit: BoxFit.cover,
                                                              image: AssetImage (
                                                                'assets/page-1/images/rectangle-1006-bg-pGF.png',
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // group29823wa7 (1:4234)
                                                          width: double.infinity,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // footballtkF (1:4235)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                child: Text(
                                                                  'Football',
                                                                  style: SafeGoogleFont (
                                                                    'Poppins',
                                                                    fontSize: 12*ffem,
                                                                    fontWeight: FontWeight.w500,
                                                                    height: 1.5*ffem/fem,
                                                                    color: Color(0xff000000),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // frame2980014B (1:4236)
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/frame-29800-RBd.png',
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // frame297958Ph (1:4252)
                                  width: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // nearbyacademygRD (1:4253)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                        child: Text(
                                          'Near by Academy',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // frame29783CPZ (1:4254)
                                        width: double.infinity,
                                        height: 126*fem,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // academayphotojPV (1:4255)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                              ),
                                              child: Container(
                                                // group29831djm (1:4261)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballncf (1:4262)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame29800uBV (1:4263)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                                                      padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                      height: double.infinity,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // starpurple5001oGs (1:4264)
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/starpurple500-1-1Bd.png',
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 6.67*fem,
                                                          ),
                                                          Container(
                                                            // starpurple5005uqh (1:4267)
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/starpurple500-5-zNK.png',
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 6.67*fem,
                                                          ),
                                                          Container(
                                                            // starpurple5006pxf (1:4270)
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/starpurple500-6-DPV.png',
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 6.67*fem,
                                                          ),
                                                          Container(
                                                            // starpurple5007kLX (1:4273)
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/starpurple500-7-V2P.png',
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            width: 6.67*fem,
                                                          ),
                                                          Container(
                                                            // starborder1fiP (1:4276)
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/starborder-1-pyM.png',
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotonY7 (1:4279)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.contain,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-1006-bg-3k3.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                // group29831Gy5 (1:4285)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballRb5 (1:4286)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame29800Lxw (1:4287)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-WUX.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotoFa7 (1:4303)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                              ),
                                              child: Container(
                                                // group29831Ah5 (1:4309)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // football76X (1:4310)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame29800q2X (1:4311)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-WBH.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphoto9Z1 (1:4327)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                              ),
                                              child: Container(
                                                // group29831fnF (1:4333)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballE4f (1:4334)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame298009hR (1:4335)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-WHV.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotoDhH (1:4351)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.contain,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-1006-bg-EyV.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                // group298316m5 (1:4357)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballrET (1:4358)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame29800mcK (1:4359)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-uXD.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphototB9 (1:4375)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                              ),
                                              child: Container(
                                                // group29831Pdh (1:4381)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballjxT (1:4382)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame298004jq (1:4383)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-Xjd.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotonA3 (1:4399)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.contain,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-1006-bg-dqH.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                // group29831fzX (1:4405)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballces (1:4406)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame29800B5h (1:4407)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-qqy.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotoH8j (1:4423)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                              ),
                                              child: Container(
                                                // group29831zJ3 (1:4429)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballwUB (1:4430)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame29800431 (1:4431)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-6bZ.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotoZEf (1:4447)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                                image: DecorationImage (
                                                  fit: BoxFit.contain,
                                                  image: AssetImage (
                                                    'assets/page-1/images/rectangle-1006-bg-SrT.png',
                                                  ),
                                                ),
                                              ),
                                              child: Container(
                                                // group29831eX1 (1:4453)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballZts (1:4454)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame298003JF (1:4455)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-ABq.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            SizedBox(
                                              width: 12*fem,
                                            ),
                                            Container(
                                              // academayphotoKWf (1:4471)
                                              padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                              width: 211*fem,
                                              height: double.infinity,
                                              decoration: BoxDecoration (
                                                color: Color(0xffffffff),
                                                borderRadius: BorderRadius.circular(8*fem),
                                              ),
                                              child: Container(
                                                // group29831dGT (1:4477)
                                                width: double.infinity,
                                                height: double.infinity,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // footballBHy (1:4478)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                      child: Text(
                                                        'Football',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w500,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // frame298006fq (1:4479)
                                                      width: 96*fem,
                                                      height: 16*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/frame-29800-J9D.png',
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // tabbarQwR (1:4501)
                    left: 0*fem,
                    top: 576*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(30.5*fem, 0*fem, 29.5*fem, 0*fem),
                      width: 375*fem,
                      height: 100*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // group8tLo (1:4506)
                            margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 29.5*fem, 0*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // homeDdy (1:4507)
                                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/home-sbD.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // homeXuZ (1:4508)
                                  'Home',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.6666666667*ffem/fem,
                                    letterSpacing: -0.5*fem,
                                    color: Color(0xff4b0000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogrouphgyv4eb (XTy7xGPFcySjezx9AshgyV)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30.75*fem, 0*fem),
                            width: 187.75*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // homeindicatorBjD (I1:4503;5:3093)
                                  left: 27*fem,
                                  top: 87*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 134*fem,
                                      height: 5*fem,
                                      child: Container(
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(100*fem),
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // group6VV1 (1:4511)
                                  left: 33*fem,
                                  top: 11*fem,
                                  child: Opacity(
                                    opacity: 0.4,
                                    child: Container(
                                      width: 28*fem,
                                      height: 44*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // autogroup4pn7CPR (XTy881c1pfRc5JYpBY4PN7)
                                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-4pn7.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                          Text(
                                            // feedJBZ (1:4515)
                                            'Feed',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6666666667*ffem/fem,
                                              letterSpacing: -0.5*fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // group9Eb1 (1:4522)
                                  left: 120*fem,
                                  top: 11*fem,
                                  child: Opacity(
                                    opacity: 0.4,
                                    child: Container(
                                      width: 40*fem,
                                      height: 44*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // ico24actionssearchwkK (1:4524)
                                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/ico-24-actions-search-Vuh.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                          Text(
                                            // searchrMV (1:4523)
                                            'Search',
                                            textAlign: TextAlign.center,
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.6666666667*ffem/fem,
                                              letterSpacing: -0.5*fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Opacity(
                            // group7zCo (1:4529)
                            opacity: 0.4,
                            child: Container(
                              margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 0*fem, 0*fem),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // userbig7YK (1:4530)
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/userbig-faX.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // profilef43 (1:4533)
                                    'Profile',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.6666666667*ffem/fem,
                                      letterSpacing: -0.5*fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
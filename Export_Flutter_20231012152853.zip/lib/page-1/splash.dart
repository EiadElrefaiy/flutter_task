import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // splashD8K (1:1007)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 812*fem,
          decoration: BoxDecoration (
            color: Color(0xffffffff),
            borderRadius: BorderRadius.circular(25*fem),
          ),
          child: Container(
            // group29832LTq (1:1096)
            width: 482.09*fem,
            height: 835*fem,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  // image18fW7 (1:1097)
                  margin: EdgeInsets.fromLTRB(294.09*fem, 0*fem, 0*fem, 551.98*fem),
                  width: 188*fem,
                  height: 222.1*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-18.png',
                  ),
                ),
                Container(
                  // image19ymh (1:1098)
                  width: 184.19*fem,
                  height: 60.92*fem,
                  child: Image.asset(
                    'assets/page-1/images/image-19-BTm.png',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // trainerteamsportVzo (1:7532)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbarPaP (1:7534)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-21-EM5.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // statusbariphonexornewerVNX (1:7543)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: 375*fem,
                    height: 44*fem,
                    child: Image.asset(
                      'assets/page-1/images/status-bar-iphone-x-or-newer-ECP.png',
                      width: 375*fem,
                      height: 44*fem,
                    ),
                  ),
                  Container(
                    // autogroupqmd1BWF (XTypigHt7HdwNZdEKdqMD1)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    height: 24*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupq3rxhjV (XTypt1MftgYPpoVmiaQ3rX)
                          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 119*fem, 0*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // arrowbackios4dd9 (1:7539)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 131.33*fem, 0*fem),
                                width: 11.67*fem,
                                height: 19.8*fem,
                                child: Image.asset(
                                  'assets/page-1/images/arrowbackios-4-ZF5.png',
                                  width: 11.67*fem,
                                  height: 19.8*fem,
                                ),
                              ),
                              Text(
                                // trainer8Zu (1:7542)
                                'Trainer',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupevq1U7y (XTypoWVAZuKXnWT9sCEVq1)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-evq1.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // frame29811Bo5 (1:7547)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 21*fem),
              width: double.infinity,
              height: 678*fem,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupwmaf7Rq (XTyqM5Qu7pVFeyiJkQwmAF)
                    padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 16*fem, 17*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // autogroupjhvySj1 (XTyq9Vurg2yNBbKTRnJHVy)
                          margin: EdgeInsets.fromLTRB(102*fem, 0*fem, 81*fem, 16*fem),
                          width: double.infinity,
                          height: 202*fem,
                          child: Container(
                            // userphotoaqD (1:7719)
                            width: 149*fem,
                            height: double.infinity,
                            child: Stack(
                              children: [
                                Positioned(
                                  // ellipse8008bq (1:7720)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 139*fem,
                                      height: 193.42*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/ellipse-800-cm5.png',
                                        width: 139*fem,
                                        height: 193.42*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // group29779e4P (1:7721)
                                  left: 60*fem,
                                  top: 179.5073242188*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 19.46*fem,
                                      height: 22.49*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/group-29779-riB.png',
                                        width: 19.46*fem,
                                        height: 22.49*fem,
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // ico24uieditGbZ (1:7783)
                                  left: 125*fem,
                                  top: 14*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 24*fem,
                                      height: 24*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/ico-24-ui-edit.png',
                                        width: 24*fem,
                                        height: 24*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // frame29808xUP (1:7618)
                          width: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // group29820iCf (1:7619)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                width: double.infinity,
                                height: 77*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(8*fem),
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // group29509qo5 (1:7620)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 17*fem, 0*fem),
                                      width: 163*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(8*fem),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // firstnamekf9 (1:7621)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'First Name',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // inbutFbu (1:7622)
                                            padding: EdgeInsets.fromLTRB(16*fem, 13*fem, 16*fem, 14*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              color: Color(0xffececec),
                                              borderRadius: BorderRadius.circular(8*fem),
                                            ),
                                            child: Text(
                                              'Ahmed',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffb1b1b1),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // group29510vxw (1:7625)
                                      width: 163*fem,
                                      height: double.infinity,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(8*fem),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // lastnamesNP (1:7626)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                            child: Text(
                                              'Last Name',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // inbutnVM (1:7627)
                                            padding: EdgeInsets.fromLTRB(16*fem, 13*fem, 16*fem, 14*fem),
                                            width: double.infinity,
                                            decoration: BoxDecoration (
                                              color: Color(0xffececec),
                                              borderRadius: BorderRadius.circular(8*fem),
                                            ),
                                            child: Text(
                                              'Zourob',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffb1b1b1),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // inbutlocationsmh (1:7630)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // genderDKm (1:7631)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      child: Text(
                                        'Gender',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff242424),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // inbutY79 (1:7632)
                                      padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 16*fem, 12*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffececec),
                                        borderRadius: BorderRadius.circular(8*fem),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // selectgenderSyD (1:7634)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 188*fem, 1*fem),
                                            child: Text(
                                              'Select Gender',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffb1b1b1),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // autogroupnfdqmVh (XTyqrp4MRe7xUNBHKfNFDq)
                                            width: 24*fem,
                                            height: 24*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/auto-group-nfdq.png',
                                              width: 24*fem,
                                              height: 24*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // inbutemailVRh (1:7641)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 17*fem),
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // dateofbirth2Rd (1:7642)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      child: Text(
                                        'Date of birth',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff242424),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // inbut8zT (1:7643)
                                      padding: EdgeInsets.fromLTRB(16*fem, 13*fem, 18*fem, 13*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffececec),
                                        borderRadius: BorderRadius.circular(8*fem),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // rfZ (1:7649)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 208*fem, 1*fem),
                                            child: Text(
                                              '26-02-1996',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffb1b1b1),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // calendartoday1nJK (1:7645)
                                            width: 20*fem,
                                            height: 22*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/calendartoday-1.png',
                                              width: 20*fem,
                                              height: 22*fem,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // inbutlocationKJF (1:7650)
                                width: double.infinity,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                      // address4Fq (1:7651)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                      child: Text(
                                        'Address',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff242424),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // inbutnSj (1:7652)
                                      padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 16*fem, 12*fem),
                                      width: double.infinity,
                                      decoration: BoxDecoration (
                                        color: Color(0xffececec),
                                        borderRadius: BorderRadius.circular(8*fem),
                                      ),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // doctorsdrivelosangelescaliforn (1:7654)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 1*fem),
                                            child: Text(
                                              '33  Doctors Drive, Los Angeles,California',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xffb1b1b1),
                                              ),
                                            ),
                                          ),
                                          Opacity(
                                            // group29511Qyu (1:7655)
                                            opacity: 0.8,
                                            child: Container(
                                              width: 24*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/group-29511.png',
                                                width: 24*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // frame29807vBZ (1:7658)
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // acountFjd (1:7659)
                          padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 18*fem, 12*fem),
                          width: double.infinity,
                          height: 66*fem,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-967-qPu.png',
                              ),
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame29806Yij (1:7661)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 113*fem, 0*fem),
                                width: 208*fem,
                                height: double.infinity,
                                child: Container(
                                  // group29502gpw (1:7665)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // challengesandtournamentsSZD (1:7666)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 208*fem,
                                            height: 21*fem,
                                            child: Text(
                                              'Challenges and tournaments',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // makechallengesforyourteamj2X (1:7667)
                                        left: 0*fem,
                                        top: 20*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 201*fem,
                                            height: 18*fem,
                                            child: Text(
                                              '(Make Challenges For your team)',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // addcircle1DTV (1:7668)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/addcircle-1-fL3.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // acountLY7 (1:7671)
                          padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 18*fem, 12*fem),
                          width: double.infinity,
                          height: 66*fem,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-967-k71.png',
                              ),
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame29806GAs (1:7673)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 173*fem, 0*fem),
                                width: 148*fem,
                                height: double.infinity,
                                child: Container(
                                  // group29502cEj (1:7677)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // achievementkrj (1:7678)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 94*fem,
                                            height: 21*fem,
                                            child: Text(
                                              'Achievement',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // addyourachievementTm9 (1:7679)
                                        left: 0*fem,
                                        top: 20*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 148*fem,
                                            height: 18*fem,
                                            child: Text(
                                              '(Add your Achievement)',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // addcircle1ZJP (1:7680)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/addcircle-1-ygB.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // acountGCo (1:7683)
                          padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 18*fem, 12*fem),
                          width: double.infinity,
                          height: 66*fem,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-967-ioH.png',
                              ),
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame29806xbR (1:7685)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 197*fem, 0*fem),
                                width: 124*fem,
                                height: double.infinity,
                                child: Container(
                                  // group29502VbM (1:7689)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // scheduleSmV (1:7690)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 66*fem,
                                            height: 21*fem,
                                            child: Text(
                                              'Schedule',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w500,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // addyourschedulewCT (1:7691)
                                        left: 0*fem,
                                        top: 20*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 124*fem,
                                            height: 18*fem,
                                            child: Text(
                                              '(Add your Schedule)',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff242424),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // addcircle1e6s (1:7692)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/addcircle-1-VDq.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // acountmSP (1:7695)
                          padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 18*fem, 9*fem),
                          width: double.infinity,
                          height: 66*fem,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-967-y3m.png',
                              ),
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame29806Hfd (1:7697)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 221*fem, 0*fem),
                                width: 100*fem,
                                height: double.infinity,
                                child: Container(
                                  // frame29502qBM (1:7701)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // sportBW7 (1:7702)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                                        child: Text(
                                          'Sport',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff242424),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // addyoursporthUT (1:7703)
                                        '(Add your Sport)',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff242424),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // addcircle1SB9 (1:7704)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/addcircle-1-jbm.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // acountYjy (1:7707)
                          padding: EdgeInsets.fromLTRB(16*fem, 16*fem, 18*fem, 9*fem),
                          width: double.infinity,
                          height: 66*fem,
                          decoration: BoxDecoration (
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/rectangle-967.png',
                              ),
                            ),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame29806sGT (1:7709)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 212*fem, 0*fem),
                                width: 109*fem,
                                height: double.infinity,
                                child: Container(
                                  // frame2950217m (1:7713)
                                  width: double.infinity,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // videos9zf (1:7714)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                                        child: Text(
                                          'Videos',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 14*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff242424),
                                          ),
                                        ),
                                      ),
                                      Text(
                                        // addyourvideossQs (1:7715)
                                        '(Add your Videos)',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff242424),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              Container(
                                // addcircle1Q9u (1:7716)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/addcircle-1-4Lf.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // homeindicator7Cj (I1:7533;5:3093)
              margin: EdgeInsets.fromLTRB(121*fem, 0*fem, 120*fem, 0*fem),
              width: double.infinity,
              height: 5*fem,
              decoration: BoxDecoration (
                borderRadius: BorderRadius.circular(100*fem),
                color: Color(0xff000000),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
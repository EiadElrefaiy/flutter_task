import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // homepG7 (1:1363)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          decoration: BoxDecoration (
            color: Color(0xffffffff),
            borderRadius: BorderRadius.circular(20*fem),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                // autogroupyxum5hq (XTxUDMGY3XWs5Jyz9ZYxum)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                width: 439*fem,
                decoration: BoxDecoration (
                  image: DecorationImage (
                    fit: BoxFit.cover,
                    image: AssetImage (
                      'assets/page-1/images/rectangle-21-1EX.png',
                    ),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Container(
                      // statusbariphonexornewer9Bu (1:2937)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                      width: 375*fem,
                      height: 44*fem,
                      child: Image.asset(
                        'assets/page-1/images/status-bar-iphone-x-or-newer-2wy.png',
                        width: 375*fem,
                        height: 44*fem,
                      ),
                    ),
                    Container(
                      // autogroupvdqhRfD (XTxUSm3rjQZmbnB1nAVDqh)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                      width: double.infinity,
                      height: 48*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // group29836kBh (1:2943)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 149*fem, 0*fem),
                            height: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // group29834HBd (1:2944)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.07*fem, 0*fem),
                                  width: 122.93*fem,
                                  height: double.infinity,
                                  child: Align(
                                    // image18R2w (1:2945)
                                    alignment: Alignment.centerLeft,
                                    child: SizedBox(
                                      width: 41*fem,
                                      height: 48*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/image-18-37u.png',
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // frame29777Xbm (1:2947)
                                  margin: EdgeInsets.fromLTRB(0*fem, 4.5*fem, 0*fem, 4.5*fem),
                                  width: 121*fem,
                                  height: double.infinity,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Container(
                                        // frame29779FXm (1:2949)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.5*fem, 0*fem),
                                        width: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // locationyCs (1:2950)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.5*fem, 0*fem),
                                              child: Text(
                                                'Location',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                            Container(
                                              // keyboardarrowdown1TNw (1:2951)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0.44*fem, 0*fem, 0*fem),
                                              width: 9*fem,
                                              height: 5.56*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/keyboardarrowdown-1.png',
                                                width: 9*fem,
                                                height: 5.56*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Text(
                                        // octobarstreet10xab (1:2954)
                                        '10 Octobar street 10,',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // ico24alertsnotificationsh2P (1:2938)
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/ico-24-alerts-notifications.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogrouptywbznB (XTxUtuxwqVk7uQzTf1tYWb)
                width: 2234*fem,
                height: 756*fem,
                child: Stack(
                  children: [
                    Positioned(
                      // frame29798LLF (1:1364)
                      left: 16*fem,
                      top: 0*fem,
                      child: Container(
                        width: 2218*fem,
                        height: 756*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // frame29783Fi7 (1:1365)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                              width: 343*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // whatsportyouarelookingfornxw (1:1366)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                    child: Text(
                                      'What Sport You are Looking For...',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // frame29797hyR (1:1367)
                                    width: double.infinity,
                                    height: 115*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // frame29796edm (1:1368)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame29782nzs (1:1369)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    height: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // group29793to1 (1:1370)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                          width: 104*fem,
                                                          height: 90*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/group-29793.png',
                                                            width: 104*fem,
                                                            height: 90*fem,
                                                          ),
                                                        ),
                                                        Text(
                                                          // trainerPzf (1:1396)
                                                          'Trainer',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame29781vzb (1:1397)
                                                height: double.infinity,
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // group29782tRd (1:1398)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                      width: 104*fem,
                                                      height: 90*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29782.png',
                                                        width: 104*fem,
                                                        height: 90*fem,
                                                      ),
                                                    ),
                                                    Text(
                                                      // fieldsCSK (1:1427)
                                                      'Fields',
                                                      style: SafeGoogleFont (
                                                        'Poppins',
                                                        fontSize: 14*ffem,
                                                        fontWeight: FontWeight.w500,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // frame29783jSF (1:1428)
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // group297944jR (1:1429)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                width: 103*fem,
                                                height: 90*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29794.png',
                                                  width: 103*fem,
                                                  height: 90*fem,
                                                ),
                                              ),
                                              Container(
                                                // academyB3M (1:1443)
                                                margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                                                child: Text(
                                                  'Academy ',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 14*ffem,
                                                    fontWeight: FontWeight.w500,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // frame29795Uo9 (1:1444)
                              width: double.infinity,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupgarbDkj (XTxVUjKw3oXGo2mvTvgarb)
                                    padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // frame29794wgj (1:1445)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                                          width: 1354*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // nearbytrainerfsd (1:1446)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                                child: Text(
                                                  'Near by Trainer',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame29792ydR (1:1447)
                                                width: double.infinity,
                                                height: 169*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    TextButton(
                                                      // userphotoHu1 (1:1448)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 100*fem,
                                                        height: double.infinity,
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              // autogroupido5jW7 (XTxW4t1hPwmA4JLgy1iDo5)
                                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                              width: double.infinity,
                                                              height: 145*fem,
                                                              child: Stack(
                                                                children: [
                                                                  Positioned(
                                                                    // group298223mh (1:1449)
                                                                    left: 0*fem,
                                                                    top: 0*fem,
                                                                    child: Container(
                                                                      width: 100*fem,
                                                                      height: 139*fem,
                                                                      child: Stack(
                                                                        children: [
                                                                          Positioned(
                                                                            // ellipse800ALX (1:1450)
                                                                            left: 0*fem,
                                                                            top: 0*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-800-qaF.png',
                                                                                  width: 100*fem,
                                                                                  height: 138.84*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // ellipse801fYB (1:1451)
                                                                            left: 0*fem,
                                                                            top: 102*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-801-JX9.png',
                                                                                  width: 100*fem,
                                                                                  height: 37*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // jennywilsonaQF (1:1452)
                                                                            left: 16*fem,
                                                                            top: 110*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 68*fem,
                                                                                height: 15*fem,
                                                                                child: Text(
                                                                                  'Jenny Wilson',
                                                                                  style: SafeGoogleFont (
                                                                                    'Poppins',
                                                                                    fontSize: 10*ffem,
                                                                                    fontWeight: FontWeight.w600,
                                                                                    height: 1.5*ffem/fem,
                                                                                    color: Color(0xffffffff),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    // group297795bu (1:1453)
                                                                    left: 43*fem,
                                                                    top: 128.8542480469*fem,
                                                                    child: Align(
                                                                      child: SizedBox(
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/group-29779-22K.png',
                                                                          width: 14*fem,
                                                                          height: 16.15*fem,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              // frame29800u59 (1:1516)
                                                              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                                                              padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                              width: double.infinity,
                                                              child: Row(
                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                children: [
                                                                  Container(
                                                                    // starpurple5001oRR (1:1517)
                                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.67*fem, 0*fem),
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/starpurple500-1-t2K.png',
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    // starpurple50057h1 (1:1520)
                                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.67*fem, 0*fem),
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/starpurple500-5-RZy.png',
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    // starpurple5006EWj (1:1523)
                                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.67*fem, 0*fem),
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/starpurple500-6-HjV.png',
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    // starpurple5007MLT (1:1526)
                                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.67*fem, 0*fem),
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/starpurple500-7.png',
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                    ),
                                                                  ),
                                                                  Container(
                                                                    // starborder1fc3 (1:1529)
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                    child: Image.asset(
                                                                      'assets/page-1/images/starborder-1-hpb.png',
                                                                      width: 13.33*fem,
                                                                      height: 12.67*fem,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotonAs (1:1532)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogrouppmckj67 (XTxWVCeWFwQVJrMxXtpmCK)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse8003Mh (1:1533)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-1Zh.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801YpF (1:1534)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilson4nb (1:1535)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779NHV (1:1539)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-GDu.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame298009Bm (1:1602)
                                                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                                                            padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // starpurple5001r6B (1:1603)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-1-UnK.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5005ZWP (1:1606)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-5-2Eb.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5006sX5 (1:1609)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-6-5dy.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5007PEX (1:1612)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-7-pEb.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starborder1JsH (1:1615)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starborder-1.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotoEW3 (1:1618)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupr6duNs9 (XTxWv76g79MbiJ11Zar6du)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800Vgs (1:1619)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-Szj.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801cFh (1:1620)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-XRH.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilsonXdZ (1:1621)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779q8T (1:1625)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-ZhR.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800rZM (1:1688)
                                                            margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 2*fem, 0*fem),
                                                            padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // starpurple5001xcP (1:1689)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-1-6wq.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple50055S7 (1:1692)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-5-czK.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple5006CFq (1:1695)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-6-Ces.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starpurple50077tb (1:1698)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starpurple500-7-hR1.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 6.67*fem,
                                                                ),
                                                                Container(
                                                                  // starborder1TBm (1:1701)
                                                                  width: 13.33*fem,
                                                                  height: 12.67*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/starborder-1-fcj.png',
                                                                    width: 13.33*fem,
                                                                    height: 12.67*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    TextButton(
                                                      // userphotoNZd (1:1704)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 100*fem,
                                                        height: double.infinity,
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              // autogroupvsrbhro (XTxXKm5vhU5UDYTfk7VSrB)
                                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                              width: double.infinity,
                                                              height: 145*fem,
                                                              child: Stack(
                                                                children: [
                                                                  Positioned(
                                                                    // group29822qTD (1:1705)
                                                                    left: 0*fem,
                                                                    top: 0*fem,
                                                                    child: Container(
                                                                      width: 100*fem,
                                                                      height: 139*fem,
                                                                      child: Stack(
                                                                        children: [
                                                                          Positioned(
                                                                            // ellipse800mLs (1:1706)
                                                                            left: 0*fem,
                                                                            top: 0*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-800-EG7.png',
                                                                                  width: 100*fem,
                                                                                  height: 138.84*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // ellipse801HKD (1:1707)
                                                                            left: 0*fem,
                                                                            top: 102*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-801-4QP.png',
                                                                                  width: 100*fem,
                                                                                  height: 37*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // jennywilsonbqh (1:1708)
                                                                            left: 16*fem,
                                                                            top: 110*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 68*fem,
                                                                                height: 15*fem,
                                                                                child: Text(
                                                                                  'Jenny Wilson',
                                                                                  style: SafeGoogleFont (
                                                                                    'Poppins',
                                                                                    fontSize: 10*ffem,
                                                                                    fontWeight: FontWeight.w600,
                                                                                    height: 1.5*ffem/fem,
                                                                                    color: Color(0xffffffff),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    // group29779u5h (1:1709)
                                                                    left: 43*fem,
                                                                    top: 128.8542480469*fem,
                                                                    child: Align(
                                                                      child: SizedBox(
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/group-29779-DPu.png',
                                                                          width: 14*fem,
                                                                          height: 16.15*fem,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              // frame29800Jdd (1:1772)
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-29800-B59.png',
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotopM5 (1:1788)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogrouptafhxiB (XTxXmzqD61sW7bDwYWTAfh)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800geB (1:1789)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-9q1.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801oD1 (1:1790)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-wVH.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilsonXPu (1:1791)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779pdu (1:1795)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-fxK.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800ecw (1:1858)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-pvb.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphoto9pb (1:1874)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupwhjftnB (XTxYDZvwCtk5GLRbxYwhJF)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800pA3 (1:1875)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-BL3.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801KMh (1:1876)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-HqH.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilsonEjZ (1:1877)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779wdy (1:1881)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-1Qs.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800xZ5 (1:1944)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-A8f.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    TextButton(
                                                      // userphotoEWb (1:1960)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 100*fem,
                                                        height: double.infinity,
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              // autogroupvh1zwA7 (XTxYa9AzJEhgpJugywvH1Z)
                                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                              width: double.infinity,
                                                              height: 145*fem,
                                                              child: Stack(
                                                                children: [
                                                                  Positioned(
                                                                    // group298223yq (1:1961)
                                                                    left: 0*fem,
                                                                    top: 0*fem,
                                                                    child: Container(
                                                                      width: 100*fem,
                                                                      height: 139*fem,
                                                                      child: Stack(
                                                                        children: [
                                                                          Positioned(
                                                                            // ellipse800ycb (1:1962)
                                                                            left: 0*fem,
                                                                            top: 0*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-800-wa7.png',
                                                                                  width: 100*fem,
                                                                                  height: 138.84*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // ellipse801tUf (1:1963)
                                                                            left: 0*fem,
                                                                            top: 102*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-801-kLf.png',
                                                                                  width: 100*fem,
                                                                                  height: 37*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // jennywilsonDWw (1:1964)
                                                                            left: 16*fem,
                                                                            top: 110*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 68*fem,
                                                                                height: 15*fem,
                                                                                child: Text(
                                                                                  'Jenny Wilson',
                                                                                  style: SafeGoogleFont (
                                                                                    'Poppins',
                                                                                    fontSize: 10*ffem,
                                                                                    fontWeight: FontWeight.w600,
                                                                                    height: 1.5*ffem/fem,
                                                                                    color: Color(0xffffffff),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    // group29779uuZ (1:1965)
                                                                    left: 43*fem,
                                                                    top: 128.8542480469*fem,
                                                                    child: Align(
                                                                      child: SizedBox(
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/group-29779-vU7.png',
                                                                          width: 14*fem,
                                                                          height: 16.15*fem,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              // frame29800KTV (1:2028)
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-29800-dDR.png',
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotochV (1:2044)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupa3ewAU7 (XTxYwoDa5YfB5egX1RA3ew)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800HYj (1:2045)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-PU3.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801nVV (1:2046)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-CJj.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilsontHd (1:2047)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779PEP (1:2051)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-HaP.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800yyH (1:2114)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-dn7.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotogco (1:2130)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupxdswpDD (XTxZKY6M9KELwQQAxRxDSw)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800jb5 (1:2131)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-D43.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801TGB (1:2132)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-RkK.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilsonnJT (1:2133)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779UBH (1:2137)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-xqD.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame298005gs (1:2200)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-TPd.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    TextButton(
                                                      // userphotoz39 (1:2216)
                                                      onPressed: () {},
                                                      style: TextButton.styleFrom (
                                                        padding: EdgeInsets.zero,
                                                      ),
                                                      child: Container(
                                                        width: 100*fem,
                                                        height: double.infinity,
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              // autogroupkpewhy9 (XTxZhGy8D5oWoA7puSkPEw)
                                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                              width: double.infinity,
                                                              height: 145*fem,
                                                              child: Stack(
                                                                children: [
                                                                  Positioned(
                                                                    // group29822pXy (1:2217)
                                                                    left: 0*fem,
                                                                    top: 0*fem,
                                                                    child: Container(
                                                                      width: 100*fem,
                                                                      height: 139*fem,
                                                                      child: Stack(
                                                                        children: [
                                                                          Positioned(
                                                                            // ellipse800LWK (1:2218)
                                                                            left: 0*fem,
                                                                            top: 0*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 138.84*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-800-bm9.png',
                                                                                  width: 100*fem,
                                                                                  height: 138.84*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // ellipse8014SK (1:2219)
                                                                            left: 0*fem,
                                                                            top: 102*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 100*fem,
                                                                                height: 37*fem,
                                                                                child: Image.asset(
                                                                                  'assets/page-1/images/ellipse-801-csq.png',
                                                                                  width: 100*fem,
                                                                                  height: 37*fem,
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                          Positioned(
                                                                            // jennywilsonzas (1:2220)
                                                                            left: 16*fem,
                                                                            top: 110*fem,
                                                                            child: Align(
                                                                              child: SizedBox(
                                                                                width: 68*fem,
                                                                                height: 15*fem,
                                                                                child: Text(
                                                                                  'Jenny Wilson',
                                                                                  style: SafeGoogleFont (
                                                                                    'Poppins',
                                                                                    fontSize: 10*ffem,
                                                                                    fontWeight: FontWeight.w600,
                                                                                    height: 1.5*ffem/fem,
                                                                                    color: Color(0xffffffff),
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          ),
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  Positioned(
                                                                    // group29779JrT (1:2221)
                                                                    left: 43*fem,
                                                                    top: 128.8542480469*fem,
                                                                    child: Align(
                                                                      child: SizedBox(
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/group-29779-yEw.png',
                                                                          width: 14*fem,
                                                                          height: 16.15*fem,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                            Container(
                                                              // frame29800KFm (1:2284)
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/frame-29800-B1h.png',
                                                                width: 96*fem,
                                                                height: 16*fem,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotodXM (1:2300)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupdkuoaSb (XTxa5GLV8EDjS9fxd6DkUo)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800JNb (1:2301)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-EU7.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801DVZ (1:2302)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-sKM.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilsonwgT (1:2303)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779Teo (1:2307)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-BRZ.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800V5h (1:2370)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800-ZH1.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 14*fem,
                                                    ),
                                                    Container(
                                                      // userphotoPRy (1:2386)
                                                      width: 100*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogrouph7cs7sm (XTxaU61nsxnn1GgMaBH7Cs)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 145*fem,
                                                            child: Stack(
                                                              children: [
                                                                Positioned(
                                                                  // ellipse800EhV (1:2387)
                                                                  left: 0*fem,
                                                                  top: 0*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 138.84*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-800-ot3.png',
                                                                        width: 100*fem,
                                                                        height: 138.84*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // ellipse801Yy5 (1:2388)
                                                                  left: 0*fem,
                                                                  top: 102*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 100*fem,
                                                                      height: 37*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/ellipse-801-CYw.png',
                                                                        width: 100*fem,
                                                                        height: 37*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // jennywilson5i7 (1:2389)
                                                                  left: 16*fem,
                                                                  top: 110*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 68*fem,
                                                                      height: 15*fem,
                                                                      child: Text(
                                                                        'Jenny Wilson',
                                                                        style: SafeGoogleFont (
                                                                          'Poppins',
                                                                          fontSize: 10*ffem,
                                                                          fontWeight: FontWeight.w600,
                                                                          height: 1.5*ffem/fem,
                                                                          color: Color(0xffffffff),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Positioned(
                                                                  // group29779nMd (1:2393)
                                                                  left: 43*fem,
                                                                  top: 128.8542480469*fem,
                                                                  child: Align(
                                                                    child: SizedBox(
                                                                      width: 14*fem,
                                                                      height: 16.15*fem,
                                                                      child: Image.asset(
                                                                        'assets/page-1/images/group-29779-hQj.png',
                                                                        width: 14*fem,
                                                                        height: 16.15*fem,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                          Container(
                                                            // frame29800zTh (1:2456)
                                                            width: 96*fem,
                                                            height: 16*fem,
                                                            child: Image.asset(
                                                              'assets/page-1/images/frame-29800.png',
                                                              width: 96*fem,
                                                              height: 16*fem,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // frame29787ieb (1:2472)
                                          width: 1772*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // nearbyfieldU7y (1:2473)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                                child: Text(
                                                  'Near by Field',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.5*ffem/fem,
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame29783mcs (1:2474)
                                                width: double.infinity,
                                                height: 126*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Container(
                                                      // fieldphotothV (1:2475)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupsqlpqcj (XTxaxjriVpRc7Hrb9MSQLP)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-fJ7.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29831KXu (1:2481)
                                                            width: double.infinity,
                                                            height: 18*fem,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footballTu1 (1:2482)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800aTq (1:2483)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                                                                  padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                                  height: double.infinity,
                                                                  child: Row(
                                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                                    children: [
                                                                      Container(
                                                                        // starpurple5001UZD (1:2484)
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/starpurple500-1-SXH.png',
                                                                          width: 13.33*fem,
                                                                          height: 12.67*fem,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        width: 6.67*fem,
                                                                      ),
                                                                      Container(
                                                                        // starpurple5005zGf (1:2487)
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/starpurple500-5-hgT.png',
                                                                          width: 13.33*fem,
                                                                          height: 12.67*fem,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        width: 6.67*fem,
                                                                      ),
                                                                      Container(
                                                                        // starpurple5006ueX (1:2490)
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/starpurple500-6-7tT.png',
                                                                          width: 13.33*fem,
                                                                          height: 12.67*fem,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        width: 6.67*fem,
                                                                      ),
                                                                      Container(
                                                                        // starpurple5007q2P (1:2493)
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/starpurple500-7-8bH.png',
                                                                          width: 13.33*fem,
                                                                          height: 12.67*fem,
                                                                        ),
                                                                      ),
                                                                      SizedBox(
                                                                        width: 6.67*fem,
                                                                      ),
                                                                      Container(
                                                                        // starborder1YBh (1:2496)
                                                                        width: 13.33*fem,
                                                                        height: 12.67*fem,
                                                                        child: Image.asset(
                                                                          'assets/page-1/images/starborder-1-ZL3.png',
                                                                          width: 13.33*fem,
                                                                          height: 12.67*fem,
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphotoSns (1:2499)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogrouph2szbfm (XTxbEjQ4yvYg2ZMEPph2sZ)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-Nsy.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823gx7 (1:2504)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // football3Xm (1:2505)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame298009qh (1:2506)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-mUj.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphotoE6T (1:2522)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupet95Mgs (XTxbUtf9Dw8itk3hLKet95)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-VgT.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823evs (1:2527)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footballQf9 (1:2528)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800vdV (1:2529)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-ueo.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphotoE8P (1:2545)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupz7nxB3d (XTxbkPDL1HZhFXsP3XZ7nX)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823sh9 (1:2550)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footballdAX (1:2551)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800TQT (1:2552)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-Qsh.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphotoy7u (1:2568)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogrouplz8j7V1 (XTxc1i78DimJRVoQueLZ8j)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-oDR.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823pPR (1:2573)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footbally1R (1:2574)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800tPH (1:2575)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-noh.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphotoCes (1:2591)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupennb9KD (XTxcHCfK15CGnHd6crEnnB)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-9GB.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823qhq (1:2596)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footballPjM (1:2597)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800iFq (1:2598)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-2ns.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphotoDyH (1:2614)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogrouppdsvAtX (XTxcYwi5doUHvKHG6gpDsV)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-Dp3.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823fqH (1:2619)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footballd1R (1:2620)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800LwR (1:2621)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-byZ.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    SizedBox(
                                                      width: 12*fem,
                                                    ),
                                                    Container(
                                                      // fieldphoto4cX (1:2637)
                                                      width: 211*fem,
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Container(
                                                            // autogroupfgqmc8F (XTxcnwJmJtpybg65C6fGqm)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                            width: double.infinity,
                                                            height: 100*fem,
                                                            decoration: BoxDecoration (
                                                              border: Border.all(color: Color(0xff4b0000)),
                                                              borderRadius: BorderRadius.circular(8*fem),
                                                              image: DecorationImage (
                                                                fit: BoxFit.cover,
                                                                image: AssetImage (
                                                                  'assets/page-1/images/rectangle-1006-bg-GqV.png',
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                          Container(
                                                            // group29823Vxj (1:2642)
                                                            width: double.infinity,
                                                            child: Row(
                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                              children: [
                                                                Container(
                                                                  // footballeaj (1:2643)
                                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                                  child: Text(
                                                                    'Football',
                                                                    style: SafeGoogleFont (
                                                                      'Poppins',
                                                                      fontSize: 12*ffem,
                                                                      fontWeight: FontWeight.w500,
                                                                      height: 1.5*ffem/fem,
                                                                      color: Color(0xff000000),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Container(
                                                                  // frame29800Nmd (1:2644)
                                                                  width: 96*fem,
                                                                  height: 16*fem,
                                                                  child: Image.asset(
                                                                    'assets/page-1/images/frame-29800-d3m.png',
                                                                    width: 96*fem,
                                                                    height: 16*fem,
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // frame29795hJ7 (1:2660)
                                    width: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // nearbyacademyF4j (1:2661)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                          child: Text(
                                            'Near by Academy',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w600,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // frame29783N9M (1:2662)
                                          width: double.infinity,
                                          height: 126*fem,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // academayphotogfq (1:2663)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                ),
                                                child: Container(
                                                  // group29831CeB (1:2669)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // football9pK (1:2670)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800g3Z (1:2671)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 1*fem),
                                                        padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                        height: double.infinity,
                                                        child: Row(
                                                          crossAxisAlignment: CrossAxisAlignment.center,
                                                          children: [
                                                            Container(
                                                              // starpurple5001yYT (1:2672)
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/starpurple500-1-7pK.png',
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 6.67*fem,
                                                            ),
                                                            Container(
                                                              // starpurple5005VFu (1:2675)
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/starpurple500-5.png',
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 6.67*fem,
                                                            ),
                                                            Container(
                                                              // starpurple5006bJw (1:2678)
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/starpurple500-6-Gw1.png',
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 6.67*fem,
                                                            ),
                                                            Container(
                                                              // starpurple5007Wwh (1:2681)
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/starpurple500-7-qkb.png',
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                              ),
                                                            ),
                                                            SizedBox(
                                                              width: 6.67*fem,
                                                            ),
                                                            Container(
                                                              // starborder1Esh (1:2684)
                                                              width: 13.33*fem,
                                                              height: 12.67*fem,
                                                              child: Image.asset(
                                                                'assets/page-1/images/starborder-1-ZHh.png',
                                                                width: 13.33*fem,
                                                                height: 12.67*fem,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotoAWT (1:2687)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.contain,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-1006-bg-y6P.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // group29831Fno (1:2693)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballQfh (1:2694)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800jCB (1:2695)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-Nt7.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotoe4F (1:2711)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                ),
                                                child: Container(
                                                  // group29831YQX (1:2717)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballVKm (1:2718)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800cfH (1:2719)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-CzK.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotovvs (1:2735)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                ),
                                                child: Container(
                                                  // group29831SeK (1:2741)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballzfq (1:2742)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800KTD (1:2743)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-ae3.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotoo7V (1:2759)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.contain,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-1006-bg-cGo.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // group29831VFD (1:2765)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballqK5 (1:2766)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800MYK (1:2767)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-Yns.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotoenK (1:2783)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                ),
                                                child: Container(
                                                  // group29831Yco (1:2789)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballgyu (1:2790)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800o2w (1:2791)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-MZR.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotou5y (1:2807)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.contain,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-1006-bg-abR.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // group29831BZH (1:2813)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballKvP (1:2814)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800eSs (1:2815)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-95y.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotokVu (1:2831)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                ),
                                                child: Container(
                                                  // group29831f75 (1:2837)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballQ4f (1:2838)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800iLF (1:2839)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-bLB.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphoto1KM (1:2855)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                  image: DecorationImage (
                                                    fit: BoxFit.contain,
                                                    image: AssetImage (
                                                      'assets/page-1/images/rectangle-1006-bg-5cj.png',
                                                    ),
                                                  ),
                                                ),
                                                child: Container(
                                                  // group29831hT5 (1:2861)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballr55 (1:2862)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800a15 (1:2863)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-7Dy.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                              SizedBox(
                                                width: 12*fem,
                                              ),
                                              Container(
                                                // academayphotogK1 (1:2879)
                                                padding: EdgeInsets.fromLTRB(0*fem, 108*fem, 0*fem, 0*fem),
                                                width: 211*fem,
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(8*fem),
                                                ),
                                                child: Container(
                                                  // group29831bRy (1:2885)
                                                  width: double.infinity,
                                                  height: double.infinity,
                                                  child: Row(
                                                    crossAxisAlignment: CrossAxisAlignment.center,
                                                    children: [
                                                      Container(
                                                        // footballMAF (1:2886)
                                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 66*fem, 0*fem),
                                                        child: Text(
                                                          'Football',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ),
                                                      Container(
                                                        // frame29800Tyy (1:2887)
                                                        width: 96*fem,
                                                        height: 16*fem,
                                                        child: Image.asset(
                                                          'assets/page-1/images/frame-29800-dQj.png',
                                                          width: 96*fem,
                                                          height: 16*fem,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      // tabbarAtP (1:2903)
                      left: 0*fem,
                      top: 576*fem,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(30.5*fem, 0*fem, 29.5*fem, 0*fem),
                        width: 375*fem,
                        height: 100*fem,
                        decoration: BoxDecoration (
                          color: Color(0xffffffff),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // group83hH (1:2908)
                              margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 29.5*fem, 0*fem),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // homeAmu (1:2909)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 0*fem),
                                    width: 24*fem,
                                    height: 24*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/home.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                  Text(
                                    // homeH5q (1:2910)
                                    'Home',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.6666666667*ffem/fem,
                                      letterSpacing: -0.5*fem,
                                      color: Color(0xff4b0000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              // autogroupkw1uCib (XTxium7YBjf3AQywv2KW1u)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 30.75*fem, 0*fem),
                              width: 187.75*fem,
                              height: double.infinity,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // homeindicator86T (I1:2905;5:3093)
                                    left: 27*fem,
                                    top: 87*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 134*fem,
                                        height: 5*fem,
                                        child: Container(
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(100*fem),
                                            color: Color(0xff000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // group6dou (1:2913)
                                    left: 33*fem,
                                    top: 11*fem,
                                    child: Opacity(
                                      opacity: 0.4,
                                      child: Container(
                                        width: 28*fem,
                                        height: 44*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // autogroupvnvd8Vm (XTxj6fy2MrFTtVpBrJVnVD)
                                              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                              width: 24*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/auto-group-vnvd.png',
                                                width: 24*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                            Text(
                                              // feedqQB (1:2917)
                                              'Feed',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.6666666667*ffem/fem,
                                                letterSpacing: -0.5*fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // group9mod (1:2924)
                                    left: 120*fem,
                                    top: 11*fem,
                                    child: Opacity(
                                      opacity: 0.4,
                                      child: Container(
                                        width: 40*fem,
                                        height: 44*fem,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // ico24actionssearchgfh (1:2926)
                                              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 0*fem),
                                              width: 24*fem,
                                              height: 24*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/ico-24-actions-search.png',
                                                width: 24*fem,
                                                height: 24*fem,
                                              ),
                                            ),
                                            Text(
                                              // searchPa7 (1:2925)
                                              'Search',
                                              textAlign: TextAlign.center,
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 12*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.6666666667*ffem/fem,
                                                letterSpacing: -0.5*fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Opacity(
                              // group7icP (1:2931)
                              opacity: 0.4,
                              child: Container(
                                margin: EdgeInsets.fromLTRB(0*fem, 11*fem, 0*fem, 0*fem),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // userbigdzF (1:2932)
                                      width: 24*fem,
                                      height: 24*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/userbig.png',
                                        width: 24*fem,
                                        height: 24*fem,
                                      ),
                                    ),
                                    Text(
                                      // profilemaf (1:2935)
                                      'Profile',
                                      textAlign: TextAlign.center,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 12*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.6666666667*ffem/fem,
                                        letterSpacing: -0.5*fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // addcardtcf (1:7957)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupajduNnj (XTyxFTk6DfqimYg9SyAJdu)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
              width: double.infinity,
              height: 115*fem,
              child: Stack(
                children: [
                  Positioned(
                    // statusbarHeo (1:8031)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                      width: 375*fem,
                      height: 115*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/rectangle-21-Ehu.png',
                          ),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // statusbariphonexornewerxW3 (1:8039)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                            width: 375*fem,
                            height: 44*fem,
                            child: Image.asset(
                              'assets/page-1/images/status-bar-iphone-x-or-newer-Acf.png',
                              width: 375*fem,
                              height: 44*fem,
                            ),
                          ),
                          Container(
                            // autogroupse1mrrK (XTyxNxXbkyDAAhkWXwSE1m)
                            margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            child: Align(
                              // arrowbackios4zBq (1:8036)
                              alignment: Alignment.bottomLeft,
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 319*fem, 0*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Image.asset(
                                      'assets/page-1/images/arrowbackios-4-ULw.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // checkoutrjq (1:8070)
                    left: 148*fem,
                    top: 53*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 42*fem,
                        child: Text(
                          'Checkout',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Montserrat',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 2.625*ffem/fem,
                            letterSpacing: -0.2399999946*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupmkvuvUo (XTyxVxKwbWtW1P9v5eMkVu)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 30*fem),
              width: 374*fem,
              height: 550*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29931ST9 (1:7958)
                    left: 129*fem,
                    top: 13*fem,
                    child: Align(
                      child: SizedBox(
                        width: 139*fem,
                        height: 202*fem,
                        child: Image.asset(
                          'assets/page-1/images/frame-29931-aB9.png',
                          width: 139*fem,
                          height: 202*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // group179MZ (1:8040)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(17*fem, 0.96*fem, 24*fem, 95.02*fem),
                      width: 374*fem,
                      height: 550*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffeded),
                        borderRadius: BorderRadius.only (
                          topLeft: Radius.circular(16*fem),
                          topRight: Radius.circular(16*fem),
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x28212121),
                            offset: Offset(0*fem, -4*fem),
                            blurRadius: 12*fem,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // addnewcardaSs (1:8064)
                            margin: EdgeInsets.fromLTRB(14*fem, 0*fem, 0*fem, 4.04*fem),
                            child: Text(
                              'Add new card',
                              style: SafeGoogleFont (
                                'Montserrat',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2175*ffem/fem,
                                letterSpacing: -0.2399999946*fem,
                                color: Color(0xff444444),
                              ),
                            ),
                          ),
                          Container(
                            // autogroup1f75sRy (XTyxehaNPhVBJjQg1n1f75)
                            width: double.infinity,
                            height: 424.98*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // oqR (1:8042)
                                  left: 10*fem,
                                  top: 334*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 194*fem,
                                      height: 15*fem,
                                      child: TextButton(
                                        onPressed: () {},
                                        style: TextButton.styleFrom (
                                          padding: EdgeInsets.zero,
                                        ),
                                        child: Text(
                                          '02                                             2027',
                                          style: SafeGoogleFont (
                                            'Montserrat',
                                            fontSize: 12*ffem,
                                            fontWeight: FontWeight.w600,
                                            height: 1.2175*ffem/fem,
                                            color: Color(0xbf000000),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // group25fsd (1:8043)
                                  left: 6*fem,
                                  top: 0*fem,
                                  child: Container(
                                    width: 327*fem,
                                    height: 424.98*fem,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogroupklj1C6s (XTyxqhG3rGhHdEBjsbkLj1)
                                          margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 8*fem, 10.79*fem),
                                          padding: EdgeInsets.fromLTRB(101*fem, 58*fem, 99*fem, 19.02*fem),
                                          width: double.infinity,
                                          decoration: BoxDecoration (
                                            border: Border.all(color: Color(0xff4b0000)),
                                            color: Color(0xfff6f6f6),
                                            borderRadius: BorderRadius.circular(16*fem),
                                          ),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // iconcontentclear24px4Py (1:8068)
                                                margin: EdgeInsets.fromLTRB(1.43*fem, 0*fem, 0*fem, 18.57*fem),
                                                width: 42.43*fem,
                                                height: 42.43*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/icon-content-clear24px.png',
                                                  width: 42.43*fem,
                                                  height: 42.43*fem,
                                                ),
                                              ),
                                              Text(
                                                // addnewcardAC7 (1:8069)
                                                'Add new card',
                                                style: SafeGoogleFont (
                                                  'Montserrat',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.2175*ffem/fem,
                                                  letterSpacing: -0.2399999946*fem,
                                                  color: Color(0xff444444),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // group19tP1 (1:8044)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26.61*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // nameDw5 (1:8045)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 29.08*fem),
                                                child: Text(
                                                  'Name',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2175*ffem/fem,
                                                    letterSpacing: -0.2399999946*fem,
                                                    color: Color(0xff444444),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // group23jeX (1:8047)
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // cardnumber5iP (1:8049)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4.13*fem),
                                                child: Text(
                                                  'Card number',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2175*ffem/fem,
                                                    letterSpacing: -0.2399999946*fem,
                                                    color: Color(0xff444444),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // autogroupbjhhCHD (XTyyqAcHeuCK26Rrs3BjHH)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 0.59*fem),
                                                width: 274*fem,
                                                height: 24.36*fem,
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      // XKV (1:8048)
                                                      left: 8*fem,
                                                      top: 0*fem,
                                                      child: Align(
                                                        child: SizedBox(
                                                          width: 266*fem,
                                                          height: 22*fem,
                                                          child: Text(
                                                            '5327    2390    1124    1717',
                                                            style: SafeGoogleFont (
                                                              'Montserrat',
                                                              fontSize: 18*ffem,
                                                              fontWeight: FontWeight.w400,
                                                              height: 1.2175*ffem/fem,
                                                              letterSpacing: 2*fem,
                                                              color: Color(0xff444444),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      // 21M (1:8066)
                                                      left: 0*fem,
                                                      top: 9.3618164062*fem,
                                                      child: Align(
                                                        child: SizedBox(
                                                          width: 235*fem,
                                                          height: 15*fem,
                                                          child: TextButton(
                                                            onPressed: () {},
                                                            style: TextButton.styleFrom (
                                                              padding: EdgeInsets.zero,
                                                            ),
                                                            child: Text(
                                                              '4563 - 6748 - 3754 - 1773                          ',
                                                              style: SafeGoogleFont (
                                                                'Montserrat',
                                                                fontSize: 12*ffem,
                                                                fontWeight: FontWeight.w600,
                                                                height: 1.2175*ffem/fem,
                                                                color: Color(0xbf000000),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // autogroupm4f1Hhy (XTyxxwYyYCDgF9RdBwM4f1)
                                          padding: EdgeInsets.fromLTRB(0*fem, 26.61*fem, 0*fem, 0*fem),
                                          width: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // group21cET (1:8055)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 26.61*fem),
                                                child: TextButton(
                                                  onPressed: () {},
                                                  style: TextButton.styleFrom (
                                                    padding: EdgeInsets.zero,
                                                  ),
                                                  child: Container(
                                                    width: 174*fem,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Container(
                                                          // expdateWKq (1:8056)
                                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4.13*fem),
                                                          child: Text(
                                                            'EXP DATE',
                                                            style: SafeGoogleFont (
                                                              'Montserrat',
                                                              fontSize: 12*ffem,
                                                              fontWeight: FontWeight.w600,
                                                              height: 1.2175*ffem/fem,
                                                              letterSpacing: -0.2399999946*fem,
                                                              color: Color(0xff444444),
                                                            ),
                                                          ),
                                                        ),
                                                        Container(
                                                          // autogroupi4yxAvB (XTyyHw1LEpVKXGx1fzi4YX)
                                                          margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 10*fem, 2.95*fem),
                                                          width: double.infinity,
                                                          height: 22*fem,
                                                          child: Row(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            children: [
                                                              Container(
                                                                // autogroup8nzd4Vm (XTyySLvyuAdGSyRTux8NZD)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                                                width: 99*fem,
                                                                height: double.infinity,
                                                                child: Stack(
                                                                  children: [
                                                                    Positioned(
                                                                      // z8X (1:8057)
                                                                      left: 0*fem,
                                                                      top: 0*fem,
                                                                      child: Align(
                                                                        child: SizedBox(
                                                                          width: 99*fem,
                                                                          height: 22*fem,
                                                                          child: Text(
                                                                            '002/2729',
                                                                            style: SafeGoogleFont (
                                                                              'Montserrat',
                                                                              fontSize: 18*ffem,
                                                                              fontWeight: FontWeight.w400,
                                                                              height: 1.2175*ffem/fem,
                                                                              letterSpacing: 2*fem,
                                                                              color: Color(0xff444444),
                                                                            ),
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Positioned(
                                                                      // vector21V5H (1:8059)
                                                                      left: 41*fem,
                                                                      top: 6.6535644531*fem,
                                                                      child: Align(
                                                                        child: SizedBox(
                                                                          width: 12*fem,
                                                                          height: 4.99*fem,
                                                                          child: Image.asset(
                                                                            'assets/page-1/images/vector-21.png',
                                                                            width: 12*fem,
                                                                            height: 4.99*fem,
                                                                          ),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              Container(
                                                                // zXq (1:8058)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                                                child: Text(
                                                                  '22',
                                                                  style: SafeGoogleFont (
                                                                    'Montserrat',
                                                                    fontSize: 18*ffem,
                                                                    fontWeight: FontWeight.w400,
                                                                    height: 1.2175*ffem/fem,
                                                                    letterSpacing: 2*fem,
                                                                    color: Color(0xff444444),
                                                                  ),
                                                                ),
                                                              ),
                                                              Container(
                                                                // vector22K4K (1:8060)
                                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.7*fem),
                                                                width: 12*fem,
                                                                height: 4.99*fem,
                                                                child: Image.asset(
                                                                  'assets/page-1/images/vector-22.png',
                                                                  width: 12*fem,
                                                                  height: 4.99*fem,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // group22dao (1:8051)
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // cvcnTh (1:8052)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4.13*fem),
                                                      child: Text(
                                                        'CVC',
                                                        style: SafeGoogleFont (
                                                          'Montserrat',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w600,
                                                          height: 1.2175*ffem/fem,
                                                          letterSpacing: -0.2399999946*fem,
                                                          color: Color(0xff444444),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // i6T (1:8053)
                                                      margin: EdgeInsets.fromLTRB(8*fem, 0*fem, 0*fem, 2.95*fem),
                                                      child: Text(
                                                        '111',
                                                        style: SafeGoogleFont (
                                                          'Montserrat',
                                                          fontSize: 18*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.2175*ffem/fem,
                                                          letterSpacing: 2*fem,
                                                          color: Color(0xff4b0000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // mohamedamrD3D (1:8065)
                                  left: 0*fem,
                                  top: 189*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 123*fem,
                                      height: 24*fem,
                                      child: Text(
                                        'Mohamed Amr',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // hDH (1:8067)
                                  left: 4*fem,
                                  top: 407*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 22*fem,
                                      height: 15*fem,
                                      child: Text(
                                        '579',
                                        style: SafeGoogleFont (
                                          'Montserrat',
                                          fontSize: 12*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1.2175*ffem/fem,
                                          color: Color(0xbf000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouphaqxans (XTyzkUQoGawCkKQfhGhAQX)
              padding: EdgeInsets.fromLTRB(15*fem, 0*fem, 17*fem, 8*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // buttonuKM (1:8028)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 53*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: double.infinity,
                        height: 48*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff4b0000),
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Center(
                          child: Text(
                            'CONFIRM  PAYMENT',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.5*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // homeindicatorZ91 (I1:8027;5:3093)
                    margin: EdgeInsets.fromLTRB(106*fem, 0*fem, 103*fem, 0*fem),
                    width: double.infinity,
                    height: 5*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // keyboardsnumericiphonemPM (1:1362)
        width: double.infinity,
        height: 291*fem,
        child: Container(
          // keyboardlighthelper6wR (I1:1362;3592:19801)
          width: double.infinity,
          height: double.infinity,
          child: Container(
            // backgroundkeyboardbg4dM (I1:1362;3592:19801;3619:3904)
            padding: EdgeInsets.fromLTRB(6*fem, 6*fem, 6*fem, 8*fem),
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration (
              color: Color(0xe5cdd1d8),
            ),
            child: ClipRect(
              child: BackdropFilter(
                filter: ImageFilter.blur (
                  sigmaX: 35*fem,
                  sigmaY: 35*fem,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroup3k5dvvT (XTxSJVHbLkfGMopEQM3k5d)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                      width: double.infinity,
                      height: 46*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // erT (I1:1362;3592:19801;3592:19686)
                            padding: EdgeInsets.fromLTRB(53.5*fem, 0*fem, 52.5*fem, 0*fem),
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-etF.png',
                                ),
                              ),
                            ),
                            child: Text(
                              '1',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Abril Fatface',
                                fontSize: 25*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.3475*ffem/fem,
                                letterSpacing: -0.5*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 6*fem,
                          ),
                          Container(
                            // 5gs (I1:1362;3592:19801;3592:19689)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-8co.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // lettersQDM (I1:1362;3592:19801;3592:19689;3592:19683)
                                  left: 47*fem,
                                  top: 29*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 23*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'ABC',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numberUj1 (I1:1362;3592:19801;3592:19689;3592:19673)
                                  left: 51.5*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 14*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '2',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 6*fem,
                          ),
                          Container(
                            // x8P (I1:1362;3592:19801;3592:19692)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-Jhu.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // lettersHAf (I1:1362;3592:19801;3592:19692;3592:19683)
                                  left: 47.5*fem,
                                  top: 29*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 22*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'DEF',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numberAkF (I1:1362;3592:19801;3592:19692;3592:19673)
                                  left: 51.5*fem,
                                  top: 0*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 14*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '3',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup7xhvTUT (XTxSbeTfoHPtarYSaS7xhV)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                      width: double.infinity,
                      height: 47*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // aZ5 (I1:1362;3592:19801;3592:19695)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // letters6XR (I1:1362;3592:19801;3592:19695;3592:19683)
                                  left: 48*fem,
                                  top: 30*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 21*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'GHI',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numbermtT (I1:1362;3592:19801;3592:19695;3592:19673)
                                  left: 51.5*fem,
                                  top: 1*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '4',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 6*fem,
                          ),
                          Container(
                            // exF (I1:1362;3592:19801;3592:19696)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-mQ3.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // lettersn2s (I1:1362;3592:19801;3592:19696;3592:19683)
                                  left: 48*fem,
                                  top: 30*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 21*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'JKL',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numbers4K (I1:1362;3592:19801;3592:19696;3592:19673)
                                  left: 52*fem,
                                  top: 1*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 13*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '5',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 6*fem,
                          ),
                          Container(
                            // w4B (I1:1362;3592:19801;3592:19697)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-SPy.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // letterssCj (I1:1362;3592:19801;3592:19697;3592:19683)
                                  left: 45.5*fem,
                                  top: 30*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 26*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'MNO',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numbermJ7 (I1:1362;3592:19801;3592:19697;3592:19673)
                                  left: 51.5*fem,
                                  top: 1*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '6',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupxqpp4HD (XTxSqitYkqNFrdJ5bPXQpP)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
                      width: double.infinity,
                      height: 47*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // B6w (I1:1362;3592:19801;3592:19721)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-WhV.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // lettersHvf (I1:1362;3592:19801;3592:19721;3592:19683)
                                  left: 43.5*fem,
                                  top: 30*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 30*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'PQRS',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numbery2o (I1:1362;3592:19801;3592:19721;3592:19673)
                                  left: 52.5*fem,
                                  top: 1*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 13*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '7',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 6*fem,
                          ),
                          Container(
                            // 3oM (I1:1362;3592:19801;3592:19722)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-sKm.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // lettersyBD (I1:1362;3592:19801;3592:19722;3592:19683)
                                  left: 47*fem,
                                  top: 30*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 23*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'TUV',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // number4TZ (I1:1362;3592:19801;3592:19722;3592:19673)
                                  left: 51.5*fem,
                                  top: 1*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '8',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            width: 6*fem,
                          ),
                          Container(
                            // Lvs (I1:1362;3592:19801;3592:19723)
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(5*fem),
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/background-primary-bg-Gg7.png',
                                ),
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  // lettersUnB (I1:1362;3592:19801;3592:19723;3592:19683)
                                  left: 43.5*fem,
                                  top: 30*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 30*fem,
                                      height: 13*fem,
                                      child: Text(
                                        'WXYZ',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abhaya Libre Medium',
                                          fontSize: 10*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.2575*ffem/fem,
                                          letterSpacing: 1.7*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // numbera4X (I1:1362;3592:19801;3592:19723;3592:19673)
                                  left: 51.5*fem,
                                  top: 1*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 15*fem,
                                      height: 34*fem,
                                      child: Text(
                                        '9',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Abril Fatface',
                                          fontSize: 25*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.3475*ffem/fem,
                                          letterSpacing: -0.5*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroupcupf51H (XTxT43sLkkRHfjCNDvCUpF)
                      margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 44.5*fem, 65*fem),
                      width: double.infinity,
                      height: 46*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // bEX (I1:1362;3592:19801;3592:19760)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 44*fem, 6*fem),
                            width: 49*fem,
                            height: 14*fem,
                            child: Image.asset(
                              'assets/page-1/images/.png',
                              width: 49*fem,
                              height: 14*fem,
                            ),
                          ),
                          Container(
                            // vGo (I1:1362;3592:19801;3592:19739)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 55.5*fem, 0*fem),
                            width: 117*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(5*fem),
                              boxShadow: [
                                BoxShadow(
                                  color: Color(0x59000000),
                                  offset: Offset(0*fem, 1*fem),
                                  blurRadius: 0*fem,
                                ),
                              ],
                            ),
                            child: Center(
                              child: Text(
                                '0',
                                textAlign: TextAlign.center,
                                style: SafeGoogleFont (
                                  'Abril Fatface',
                                  fontSize: 25*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.3475*ffem/fem,
                                  letterSpacing: -0.5*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // deletea6T (I1:1362;3592:19801;3592:19742)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 2*fem),
                            width: 23*fem,
                            height: 17*fem,
                            child: Image.asset(
                              'assets/page-1/images/delete.png',
                              width: 23*fem,
                              height: 17*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // draggergvB (I1:1362;3592:19801;3592:19761)
                      margin: EdgeInsets.fromLTRB(114*fem, 0*fem, 114*fem, 0*fem),
                      width: double.infinity,
                      height: 5*fem,
                      decoration: BoxDecoration (
                        borderRadius: BorderRadius.circular(5*fem),
                        color: Color(0xff000000),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
          );
  }
}
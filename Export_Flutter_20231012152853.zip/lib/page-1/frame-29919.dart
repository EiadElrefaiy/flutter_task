import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 276;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // frame29919ixw (1:7479)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 356*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogrouphlzvBrX (XTyn9Fas23wGwunv9VhLZV)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
              padding: EdgeInsets.fromLTRB(16*fem, 60*fem, 16*fem, 12*fem),
              width: double.infinity,
              height: 120*fem,
              decoration: BoxDecoration (
                color: Color(0xfff9e3e3),
              ),
              child: Container(
                // logog2b (1:7520)
                width: 170*fem,
                height: double.infinity,
                child: Stack(
                  children: [
                    Positioned(
                      // group29834cwq (1:7521)
                      left: 0*fem,
                      top: 0*fem,
                      child: Container(
                        width: 122.93*fem,
                        height: 48*fem,
                        child: Align(
                          // image18kHM (1:7522)
                          alignment: Alignment.centerLeft,
                          child: SizedBox(
                            width: 41*fem,
                            height: 48*fem,
                            child: Image.asset(
                              'assets/page-1/images/image-18-Rks.png',
                            ),
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      // frame29777GmV (1:7524)
                      left: 49*fem,
                      top: 4.5*fem,
                      child: Container(
                        width: 121*fem,
                        height: 39*fem,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              // frame29779Pr7 (1:7526)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.5*fem, 0*fem),
                              width: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // locationJiB (1:7527)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.5*fem, 0*fem),
                                    child: Text(
                                      'Location',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // keyboardarrowdown1aQo (1:7528)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0.44*fem, 0*fem, 0*fem),
                                    width: 9*fem,
                                    height: 5.56*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/keyboardarrowdown-1-qvP.png',
                                      width: 9*fem,
                                      height: 5.56*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              // octobarstreet104qm (1:7531)
                              '10 Octobar street 10,',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              // autogrouppztwPt3 (XTynNL3Qa6XT6jCe5vPztw)
              margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 0*fem, 0*fem),
              width: 182*fem,
              height: 312*fem,
              child: Container(
                // frame29924LHV (1:7482)
                width: 150*fem,
                height: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // autogroupxk9mfaf (XTyo74KD9W8eUX8Wg3xk9M)
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // frame8ybM (1:7483)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 62*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // homei39 (1:7484)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/home-HNP.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // homeoqH (1:7485)
                                  'Home',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 24*fem,
                          ),
                          Container(
                            // autogroupcjejXWP (XTynXA82ejjozVQDwbcJej)
                            width: 108*fem,
                            height: 72*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // frame6saF (1:7486)
                                  left: 0*fem,
                                  top: 0*fem,
                                  child: Container(
                                    padding: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                                    width: 79*fem,
                                    height: 67*fem,
                                    child: Container(
                                      // autogroupeds7PHh (XTyneKam4CeX1zhHLPedS7)
                                      width: double.infinity,
                                      height: 24*fem,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // rssfeed18FH (1:7490)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0.44*fem, 20.44*fem, 0*fem),
                                            width: 15.56*fem,
                                            height: 15.56*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/rssfeed-1.png',
                                              width: 15.56*fem,
                                              height: 15.56*fem,
                                            ),
                                          ),
                                          Text(
                                            // feedSFy (1:7494)
                                            'Feed',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w500,
                                              height: 1.5*ffem/fem,
                                              color: Color(0xff000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // frame29919NQX (1:7495)
                                  left: 0*fem,
                                  top: 48*fem,
                                  child: Container(
                                    width: 108*fem,
                                    height: 24*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // ico24useruserbig5pj (1:7496)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          width: 24*fem,
                                          height: 24*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/ico-24-user-userbig.png',
                                            width: 24*fem,
                                            height: 24*fem,
                                          ),
                                        ),
                                        Text(
                                          // accountbHH (1:7499)
                                          'Account',
                                          style: SafeGoogleFont (
                                            'Poppins',
                                            fontSize: 16*ffem,
                                            fontWeight: FontWeight.w500,
                                            height: 1.5*ffem/fem,
                                            color: Color(0xff242424),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 24*fem,
                          ),
                          Container(
                            // frame29920vaT (1:7500)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 54*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ico24actionshistoryTKV (1:7501)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ico-24-actions-history.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // historyZ7d (1:7504)
                                  'History',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff242424),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 24*fem,
                          ),
                          Container(
                            // frame29921HJX (1:7505)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 53*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ico24uisettings21D (1:7506)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ico-24-ui-settings.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // settingvcP (1:7509)
                                  'Setting',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff242424),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(
                            height: 24*fem,
                          ),
                          Container(
                            // frame29922Esy (1:7510)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 73*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ico24actionshelpyaf (1:7511)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                  width: 24*fem,
                                  height: 24*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/ico-24-actions-help.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                                Text(
                                  // helpVJ7 (1:7514)
                                  'Help',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 16*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff242424),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // frame29923qcs (1:7515)
                      width: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // ico24usergroupaddo3u (1:7516)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/ico-24-user-groupadd.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                          Text(
                            // inviteafrinedWU7 (1:7519)
                            'invite a frined',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.5*ffem/fem,
                              color: Color(0xff242424),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
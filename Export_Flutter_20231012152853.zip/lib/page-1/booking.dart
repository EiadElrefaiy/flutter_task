import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // booking9B5 (1:7786)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupta3he7q (XTysdG7eU4qcGAsapvTA3H)
              width: double.infinity,
              height: 115*fem,
              child: Stack(
                children: [
                  Positioned(
                    // statusbarkwZ (1:7872)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 23*fem),
                      width: 375*fem,
                      height: 115*fem,
                      decoration: BoxDecoration (
                        image: DecorationImage (
                          fit: BoxFit.cover,
                          image: AssetImage (
                            'assets/page-1/images/rectangle-21-fHh.png',
                          ),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // statusbariphonexornewercTy (1:7880)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                            width: 375*fem,
                            height: 44*fem,
                            child: Image.asset(
                              'assets/page-1/images/status-bar-iphone-x-or-newer-QQP.png',
                              width: 375*fem,
                              height: 44*fem,
                            ),
                          ),
                          Container(
                            // autogroupkfkj7Qj (XTysmWNuZVkC13TPDnkfkj)
                            margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                            padding: EdgeInsets.fromLTRB(0*fem, 8*fem, 0*fem, 0*fem),
                            width: double.infinity,
                            child: Align(
                              // arrowbackios4d8B (1:7877)
                              alignment: Alignment.bottomLeft,
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: Container(
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 319*fem, 0*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Image.asset(
                                      'assets/page-1/images/arrowbackios-4-bom.png',
                                      width: 24*fem,
                                      height: 24*fem,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // checkoutJk7 (1:7956)
                    left: 144*fem,
                    top: 53*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 42*fem,
                        child: Text(
                          'Checkout',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Montserrat',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 2.625*ffem/fem,
                            letterSpacing: -0.2399999946*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcacoZvw (XTysuqUMwPGTLKz1YCcaco)
              width: double.infinity,
              height: 930.96*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29931uE7 (1:7787)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 375*fem,
                      height: 562*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffeded),
                      ),
                      child: Stack(
                        children: [
                          Positioned(
                            // cardsbsd (1:7855)
                            left: 32*fem,
                            top: 9*fem,
                            child: Container(
                              width: 311*fem,
                              height: 248*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // cardbgredjD9 (1:7856)
                                    left: 8*fem,
                                    top: 0*fem,
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        width: 295*fem,
                                        height: 193.59*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // rectangle9eL7 (I1:7856;1:2200)
                                              left: 12.90625*fem,
                                              top: 44.25*fem,
                                              child: ImageFiltered(
                                                imageFilter: ImageFilter.blur (
                                                  sigmaX: 14.75*fem,
                                                  sigmaY: 14.75*fem,
                                                ),
                                                child: Align(
                                                  child: SizedBox(
                                                    width: 270.11*fem,
                                                    height: 149.34*fem,
                                                    child: Container(
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(29.5*fem),
                                                        color: Color(0x7a4b4b4b),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // autogroupabzfKSF (XTryiAeAQmYiiD959daBzF)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 295*fem,
                                                  height: 184.38*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/auto-group-abzf.png',
                                                    width: 295*fem,
                                                    height: 184.38*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // cardsmainbef (1:7857)
                                    left: 4*fem,
                                    top: 12*fem,
                                    child: TextButton(
                                      onPressed: () {},
                                      style: TextButton.styleFrom (
                                        padding: EdgeInsets.zero,
                                      ),
                                      child: Container(
                                        width: 303*fem,
                                        height: 204.6*fem,
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              // cardbggray6bR (I1:7857;1:686)
                                              left: 0*fem,
                                              top: 0*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 303*fem,
                                                  height: 204.6*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/cardbg-gray.png',
                                                    width: 303*fem,
                                                    height: 204.6*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // shapeCeT (I1:7857;2:69)
                                              left: 46.0007324219*fem,
                                              top: 152.3879394531*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 26.78*fem,
                                                  height: 14.55*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/shape-cLX.png',
                                                    width: 26.78*fem,
                                                    height: 14.55*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // shapeJSb (I1:7857;2:75)
                                              left: 208.2807617188*fem,
                                              top: 153.9072265625*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 22.35*fem,
                                                  height: 4.73*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/shape-itF.png',
                                                    width: 22.35*fem,
                                                    height: 4.73*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // expriresdate2Nb (I1:7857;2:79)
                                              left: 43.8425292969*fem,
                                              top: 128.6044921875*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 56*fem,
                                                  height: 25*fem,
                                                  child: Text(
                                                    'EXPRIRES DATE',
                                                    style: SafeGoogleFont (
                                                      'Aclonica',
                                                      fontSize: 10.7170419693*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1325*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // holdernameWoZ (I1:7857;2:80)
                                              left: 43.8425292969*fem,
                                              top: 18.5112304688*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 48*fem,
                                                  height: 25*fem,
                                                  child: Text(
                                                    'HOLDER NAME',
                                                    style: SafeGoogleFont (
                                                      'Aclonica',
                                                      fontSize: 10.7170419693*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1325*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // cvcCwH (I1:7857;2:81)
                                              left: 206.5466308594*fem,
                                              top: 128.6044921875*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 24*fem,
                                                  height: 13*fem,
                                                  child: Text(
                                                    'CVC',
                                                    style: SafeGoogleFont (
                                                      'Aclonica',
                                                      fontSize: 10.7170419693*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1325*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // yournamehere7HZ (I1:7857;2:82)
                                              left: 43.8425292969*fem,
                                              top: 36.0483398438*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 101*fem,
                                                  height: 36*fem,
                                                  child: Text(
                                                    'YOUR NAME HERE',
                                                    style: SafeGoogleFont (
                                                      'Aclonica',
                                                      fontSize: 15.5884246826*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1325*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Positioned(
                                              // ow5 (I1:7857;2:83)
                                              left: 56.5080566406*fem,
                                              top: 89.0842285156*fem,
                                              child: Align(
                                                child: SizedBox(
                                                  width: 201.05*fem,
                                                  height: 10.66*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/-3sd.png',
                                                    width: 201.05*fem,
                                                    height: 10.66*fem,
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // rectangle98TZ (1:7858)
                                    left: 9*fem,
                                    top: 86*fem,
                                    child: ImageFiltered(
                                      imageFilter: ImageFilter.blur (
                                        sigmaX: 16*fem,
                                        sigmaY: 16*fem,
                                      ),
                                      child: Align(
                                        child: SizedBox(
                                          width: 293*fem,
                                          height: 162*fem,
                                          child: Container(
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(32*fem),
                                              color: Color(0x38cacaca),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // cardEFh (1:7859)
                                    left: 1.2556152344*fem,
                                    top: 26*fem,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(23.74*fem, 16*fem, 23.74*fem, 27.54*fem),
                                      width: 308.49*fem,
                                      height: 195.07*fem,
                                      decoration: BoxDecoration (
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/clipped.png',
                                          ),
                                        ),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // holdernameJmM (I1:7859;2:20)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                                            child: Text(
                                              'HOLDER NAME',
                                              style: SafeGoogleFont (
                                                'Aclonica',
                                                fontSize: 11*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.1325*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // yournamehereRLB (I1:7859;2:22)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
                                            child: Text(
                                              'YOUR NAME HERE',
                                              style: SafeGoogleFont (
                                                'Aclonica',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.1325*ffem/fem,
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // Xe7 (I1:7859;2:23)
                                            margin: EdgeInsets.fromLTRB(13*fem, 0*fem, 0*fem, 30.11*fem),
                                            width: 206.36*fem,
                                            height: 10.89*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/-asR.png',
                                              width: 206.36*fem,
                                              height: 10.89*fem,
                                            ),
                                          ),
                                          Container(
                                            // autogroupkqx3pt7 (XTytTQQ6VJSBCoFARRKqx3)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 69*fem, 10.67*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // expriresdateLrT (I1:7859;2:19)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 76*fem, 0*fem),
                                                  child: Text(
                                                    'EXPRIRES DATE',
                                                    style: SafeGoogleFont (
                                                      'Aclonica',
                                                      fontSize: 11*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.1325*ffem/fem,
                                                      color: Color(0xffffffff),
                                                    ),
                                                  ),
                                                ),
                                                Text(
                                                  // cvces9 (I1:7859;2:21)
                                                  'CVC',
                                                  style: SafeGoogleFont (
                                                    'Aclonica',
                                                    fontSize: 11*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1325*ffem/fem,
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // autogroupdn6bQLX (XTytZeigmiaNhm98fEDn6b)
                                            margin: EdgeInsets.fromLTRB(2.22*fem, 0*fem, 69.27*fem, 0*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // shapeYBq (I1:7859;2:9)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 139.07*fem, 0*fem),
                                                  width: 27.49*fem,
                                                  height: 14.86*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/shape.png',
                                                    width: 27.49*fem,
                                                    height: 14.86*fem,
                                                  ),
                                                ),
                                                Container(
                                                  // shapefGT (I1:7859;2:15)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 1.55*fem, 0*fem, 0*fem),
                                                  width: 22.95*fem,
                                                  height: 4.83*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/shape-7no.png',
                                                    width: 22.95*fem,
                                                    height: 4.83*fem,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // addnewcardBVh (1:7860)
                                    left: 0*fem,
                                    top: 31*fem,
                                    child: Container(
                                      padding: EdgeInsets.fromLTRB(100*fem, 61.79*fem, 100*fem, 58*fem),
                                      width: 311*fem,
                                      height: 190*fem,
                                      decoration: BoxDecoration (
                                        border: Border.all(color: Color(0xffd0d0d0)),
                                        color: Color(0xfff6f6f6),
                                        borderRadius: BorderRadius.circular(16*fem),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // iconcontentclear24pxf9y (I1:7860;3:1424)
                                            margin: EdgeInsets.fromLTRB(1.43*fem, 0*fem, 0*fem, 7.79*fem),
                                            width: 42.43*fem,
                                            height: 42.43*fem,
                                            child: Image.asset(
                                              'assets/page-1/images/icon-content-clear24px-7VZ.png',
                                              width: 42.43*fem,
                                              height: 42.43*fem,
                                            ),
                                          ),
                                          Text(
                                            // addnewcardAMd (I1:7860;3:1423)
                                            'Add new card',
                                            style: SafeGoogleFont (
                                              'Montserrat',
                                              fontSize: 16*ffem,
                                              fontWeight: FontWeight.w500,
                                              height: 1.2175*ffem/fem,
                                              letterSpacing: -0.2399999946*fem,
                                              color: Color(0xff444444),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // group13Veo (1:7861)
                                    left: 129*fem,
                                    top: 231*fem,
                                    child: Container(
                                      width: 52*fem,
                                      height: 8*fem,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Container(
                                            // ellipse15bxj (1:7862)
                                            width: 8*fem,
                                            height: 8*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(4*fem),
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 3*fem,
                                          ),
                                          TextButton(
                                            // ellipse16L9d (1:7863)
                                            onPressed: () {},
                                            style: TextButton.styleFrom (
                                              padding: EdgeInsets.zero,
                                            ),
                                            child: Container(
                                              width: 8*fem,
                                              height: 8*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(4*fem),
                                                border: Border.all(color: Color(0xffbae2ef)),
                                                color: Color(0xff0f3153),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 3*fem,
                                          ),
                                          Container(
                                            // ellipse17pab (1:7864)
                                            width: 8*fem,
                                            height: 8*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(4*fem),
                                              border: Border.all(color: Color(0xffbae2ef)),
                                              color: Color(0xff0f3153),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 3*fem,
                                          ),
                                          Container(
                                            // ellipse189cs (1:7865)
                                            width: 8*fem,
                                            height: 8*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(4*fem),
                                              border: Border.all(color: Color(0xffbae2ef)),
                                              color: Color(0xff0f3153),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 3*fem,
                                          ),
                                          Container(
                                            // ellipse19GBh (1:7866)
                                            width: 8*fem,
                                            height: 8*fem,
                                            decoration: BoxDecoration (
                                              borderRadius: BorderRadius.circular(4*fem),
                                              border: Border.all(color: Color(0xffbae2ef)),
                                              color: Color(0xff0f3153),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle12Cb9 (1:7881)
                            left: 17*fem,
                            top: 252*fem,
                            child: Align(
                              child: SizedBox(
                                width: 340*fem,
                                height: 296*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(24*fem),
                                    color: Color(0xffffffff),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x28212121),
                                        offset: Offset(0*fem, -4*fem),
                                        blurRadius: 12*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1016sSP (1:7867)
                    left: 0*fem,
                    top: 583*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 114*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // homeindicatorP9q (I1:7868;5:3093)
                    left: 121*fem,
                    top: 684*fem,
                    child: Align(
                      child: SizedBox(
                        width: 134*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // buttonhAX (1:7869)
                    left: 16*fem,
                    top: 583*fem,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        width: 343*fem,
                        height: 48*fem,
                        decoration: BoxDecoration (
                          color: Color(0xff4b0000),
                          borderRadius: BorderRadius.circular(8*fem),
                        ),
                        child: Center(
                          child: Text(
                            'BOOKING NOW',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w500,
                              height: 1.5*ffem/fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // curentbalancek8o (1:7882)
                    left: 48.8879394531*fem,
                    top: 258.2109375*fem,
                    child: Container(
                      width: 277.6*fem,
                      height: 672.75*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup6paffWf (XTyvBGhMjW5fbodrJp6PAF)
                            padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 22.98*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // currentbalancebQK (1:7896)
                                  margin: EdgeInsets.fromLTRB(9.12*fem, 0*fem, 0*fem, 7.81*fem),
                                  child: Text(
                                    'Current Balance ',
                                    style: SafeGoogleFont (
                                      'Montserrat',
                                      fontSize: 15*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.2175*ffem/fem,
                                      letterSpacing: -0.3834800124*fem,
                                      color: Color(0xff1b1b2f),
                                    ),
                                  ),
                                ),
                                Container(
                                  // hiF (1:7895)
                                  margin: EdgeInsets.fromLTRB(9.12*fem, 0*fem, 0*fem, 32.76*fem),
                                  child: Text(
                                    '\$50.00',
                                    style: SafeGoogleFont (
                                      'Montserrat',
                                      fontSize: 24*ffem,
                                      fontWeight: FontWeight.w700,
                                      height: 1.2175*ffem/fem,
                                      letterSpacing: -0.6646986604*fem,
                                      color: Color(0xff1b1b2f),
                                    ),
                                  ),
                                ),
                                Container(
                                  // autogroupndlkR8T (XTyu9y4qgn3d9rbZ1QNDLK)
                                  width: 201.11*fem,
                                  height: 93.42*fem,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        // paidbyZVZ (1:7906)
                                        left: 0*fem,
                                        top: 0*fem,
                                        child: Container(
                                          width: 198.96*fem,
                                          height: 93.42*fem,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // autogroupc7rhsFM (XTyuKYdDKYo8PLJaAyc7Rh)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4.47*fem),
                                                width: double.infinity,
                                                height: 68.95*fem,
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // paidbynt7 (1:7907)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24.62*fem, 9.79*fem),
                                                      padding: EdgeInsets.fromLTRB(16.35*fem, 10.86*fem, 14.73*fem, 8.98*fem),
                                                      decoration: BoxDecoration (
                                                        borderRadius: BorderRadius.circular(4.9302325249*fem),
                                                      ),
                                                      child: Center(
                                                        // qrcodeVnX (1:7909)
                                                        child: SizedBox(
                                                          width: 17.26*fem,
                                                          height: 32.05*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/qr-code.png',
                                                            width: 17.26*fem,
                                                            height: 32.05*fem,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // autogroupdgjb2Gf (XTyuPxfXMsQJqDQN6pDGJb)
                                                      height: double.infinity,
                                                      child: Column(
                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                        children: [
                                                          Container(
                                                            // paidbyAtf (1:7918)
                                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28.95*fem),
                                                            child: Text(
                                                              'Paid by',
                                                              style: SafeGoogleFont (
                                                                'Montserrat',
                                                                fontSize: 16*ffem,
                                                                fontWeight: FontWeight.w700,
                                                                height: 1.2175*ffem/fem,
                                                                letterSpacing: -0.3834800124*fem,
                                                                color: Color(0xff1b1b2f),
                                                              ),
                                                            ),
                                                          ),
                                                          Text(
                                                            // xxxxxxxxx19gc7 (1:7919)
                                                            '010x xxxxx xxx 19',
                                                            style: SafeGoogleFont (
                                                              'Montserrat',
                                                              fontSize: 16*ffem,
                                                              fontWeight: FontWeight.w400,
                                                              height: 1.2175*ffem/fem,
                                                              letterSpacing: -0.3834800124*fem,
                                                              color: Color(0xff1b1b2f),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // DM9 (1:7920)
                                                margin: EdgeInsets.fromLTRB(4.96*fem, 0*fem, 0*fem, 0*fem),
                                                child: Text(
                                                  '01/17/22',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.2175*ffem/fem,
                                                    letterSpacing: -0.3834800124*fem,
                                                    color: Color(0xff1b1b2f),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Positioned(
                                        // mohamedamr8U7 (1:7922)
                                        left: 78.1120605469*fem,
                                        top: 22.2244873047*fem,
                                        child: Align(
                                          child: SizedBox(
                                            width: 123*fem,
                                            height: 24*fem,
                                            child: Text(
                                              'Mohamed Amr',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 16*ffem,
                                                fontWeight: FontWeight.w600,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroup5uctRTD (XTyuehjxb6J8rHicW85ucT)
                            width: double.infinity,
                            height: 466.78*fem,
                            child: Stack(
                              children: [
                                Positioned(
                                  // group25xi3 (1:7883)
                                  left: 39.2160644531*fem,
                                  top: 0*fem,
                                  child: Opacity(
                                    opacity: 0,
                                    child: Container(
                                      width: 238.38*fem,
                                      height: 466.78*fem,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.end,
                                        children: [
                                          Container(
                                            // group8fcT (1:7887)
                                            margin: EdgeInsets.fromLTRB(199.38*fem, 0*fem, 0*fem, 344.11*fem),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              children: [
                                                Container(
                                                  // group71AX (1:7889)
                                                  width: 36.48*fem,
                                                  height: 22.36*fem,
                                                  child: Image.asset(
                                                    'assets/page-1/images/group-7.png',
                                                    width: 36.48*fem,
                                                    height: 22.36*fem,
                                                  ),
                                                ),
                                                Text(
                                                  // mastercardLCo (1:7888)
                                                  'mastercard',
                                                  textAlign: TextAlign.center,
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 7*ffem,
                                                    fontWeight: FontWeight.w600,
                                                    height: 1.2175*ffem/fem,
                                                    letterSpacing: -0.2399999946*fem,
                                                    color: Color(0xff292929),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // autogroupjdnfUK1 (XTyuoXpafjWVk3vCMoJDNF)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 19.5*fem, 14.91*fem),
                                            width: 218.88*fem,
                                            height: 44.72*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xfff8eb03),
                                              borderRadius: BorderRadius.circular(24*fem),
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Color(0x7af8eb03),
                                                  offset: Offset(0*fem, 4*fem),
                                                  blurRadius: 4*fem,
                                                ),
                                              ],
                                            ),
                                            child: Center(
                                              child: Text(
                                                'ADD NEW CARD',
                                                style: SafeGoogleFont (
                                                  'Montserrat',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w600,
                                                  height: 1.2175*ffem/fem,
                                                  letterSpacing: -0.2399999946*fem,
                                                  color: Color(0xff444444),
                                                ),
                                              ),
                                            ),
                                          ),
                                          Container(
                                            // barshomeindicatoriphonelightpo (1:7884)
                                            margin: EdgeInsets.fromLTRB(42.34*fem, 0*fem, 62.04*fem, 0*fem),
                                            padding: EdgeInsets.fromLTRB(0*fem, 19*fem, 0*fem, 7.68*fem),
                                            width: double.infinity,
                                            height: 31.68*fem,
                                            decoration: BoxDecoration (
                                              color: Color(0xffffffff),
                                            ),
                                            child: Center(
                                              // homeindicatormhR (I1:7884;0:566)
                                              child: SizedBox(
                                                width: double.infinity,
                                                height: 5*fem,
                                                child: Container(
                                                  decoration: BoxDecoration (
                                                    borderRadius: BorderRadius.circular(100*fem),
                                                    color: Color(0xff000000),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // paidtotn3 (1:7897)
                                  left: 0*fem,
                                  top: 9.8809814453*fem,
                                  child: Container(
                                    width: 185.96*fem,
                                    height: 68.95*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // paidto2NT (1:7898)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24.62*fem, 15.66*fem),
                                          padding: EdgeInsets.fromLTRB(12.93*fem, 18.1*fem, 13.49*fem, 16.89*fem),
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(4.9302325249*fem),
                                          ),
                                          child: Center(
                                            // walletwkK (1:7900)
                                            child: SizedBox(
                                              width: 21.92*fem,
                                              height: 16.89*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/wallet.png',
                                                width: 21.92*fem,
                                                height: 16.89*fem,
                                              ),
                                            ),
                                          ),
                                        ),
                                        Container(
                                          // autogroupphsufAX (XTyv12VRq4Qhd2NDktPHsu)
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // paidto1VH (1:7904)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 28.95*fem),
                                                child: Text(
                                                  'Paid to',
                                                  style: SafeGoogleFont (
                                                    'Montserrat',
                                                    fontSize: 16*ffem,
                                                    fontWeight: FontWeight.w700,
                                                    height: 1.2175*ffem/fem,
                                                    letterSpacing: -0.3834800124*fem,
                                                    color: Color(0xff1b1b2f),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // Kks (1:7905)
                                                '12356 0800963',
                                                style: SafeGoogleFont (
                                                  'Montserrat',
                                                  fontSize: 16*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.2175*ffem/fem,
                                                  letterSpacing: -0.3834800124*fem,
                                                  color: Color(0xff1b1b2f),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // jennywilsonTcB (1:7921)
                                  left: 78.1120605469*fem,
                                  top: 37.8193359375*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 109*fem,
                                      height: 24*fem,
                                      child: Text(
                                        'Jenny Wilson',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  // flagofegypt3MhZ (1:7923)
                                  left: 166.1120605469*fem,
                                  top: 10.8193359375*fem,
                                  child: Align(
                                    child: SizedBox(
                                      width: 21*fem,
                                      height: 14*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/flagofegypt-3.png',
                                        width: 21*fem,
                                        height: 14*fem,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
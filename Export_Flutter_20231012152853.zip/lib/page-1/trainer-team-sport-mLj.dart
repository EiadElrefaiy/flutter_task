import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // trainerteamsportbk3 (1:4547)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbarGLP (1:5434)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-21-KUT.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // statusbariphonexornewerxj1 (1:5443)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: 375*fem,
                    height: 44*fem,
                    child: Image.asset(
                      'assets/page-1/images/status-bar-iphone-x-or-newer-1tB.png',
                      width: 375*fem,
                      height: 44*fem,
                    ),
                  ),
                  Container(
                    // autogroupgc6k3kT (XTyQ18yX5T7xf1QSZtgC6K)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextButton(
                          // arrowbackios4NXq (1:5439)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/arrowbackios-4-ntF.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 119*fem,
                        ),
                        Text(
                          // trainerf19 (1:5442)
                          'Trainer',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        SizedBox(
                          width: 119*fem,
                        ),
                        Container(
                          // autogroupsltrm4B (XTyQ6PKmxMsy31xVjAsLTR)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-sltr.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupclphggw (XTyFLdup51Wa8HXc4FcLPh)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
              width: double.infinity,
              height: 241*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group7166zhd (1:5424)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 375*fem,
                      height: 47*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupla7qiNj (XTyFdJ6ipnZ6nrarh5LA7q)
                            padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 17*fem, 6*fem),
                            width: double.infinity,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // individualouy (1:5426)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Text(
                                      'Individual',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 34*fem,
                                ),
                                Container(
                                  // autogroup8tjjHaF (XTyFk8Eg6R15Si6cPh8tJj)
                                  width: 81*fem,
                                  height: double.infinity,
                                  child: Text(
                                    'Team Sport',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 34*fem,
                                ),
                                Container(
                                  // gymnG7 (1:5428)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Text(
                                      'Gym',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 34*fem,
                                ),
                                Container(
                                  // exsportfao (1:5429)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: Text(
                                    'EX Sport',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupxb2wBp3 (XTyFvcwBrEX6CjCiiFXB2w)
                            margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                            width: double.infinity,
                            height: 2*fem,
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group29809i3H (1:5448)
                    left: 0*fem,
                    top: 45*fem,
                    child: Container(
                      width: 375*fem,
                      height: 196*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupjbsfdAF (XTyGEn5biGduYjGqxsJBSF)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            width: double.infinity,
                            height: 180*fem,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-1010-bg.png',
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // frame29799jyy (1:5450)
                            margin: EdgeInsets.fromLTRB(160*fem, 0*fem, 159*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse803sKV (1:5451)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0xff4b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse804bWP (1:5452)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse805iqu (1:5453)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse806Faw (1:5454)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupx63roMZ (XTyGPXL2WTEar5Xbtzx63R)
              width: double.infinity,
              height: 463*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame298038ud (1:4548)
                    left: 16*fem,
                    top: 0*fem,
                    child: Container(
                      width: 343*fem,
                      height: 453*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // teamsporttrainerTh1 (1:4549)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                            child: Text(
                              'Team Sport Trainer',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // frame29802NJB (1:4550)
                            width: double.infinity,
                            height: 413*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // trainerdetailsgZm (1:4551)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupd2bhCo1 (XTyGovo2euVbh3VhPRd2bH)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo8wZ (1:4581)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800567 (1:4582)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-9wu.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779nWK (1:4586)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-RsM.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailspxo (1:4557)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame298019EP (1:4561)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804U1m (1:4562)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // albertfloresopj (1:4563)
                                                          'Albert Flores',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorwR9 (1:4564)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800sZh (1:4565)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001zuD (1:4566)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-hdR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005hHq (1:4569)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-QJb.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006Qxw (1:4572)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-BR9.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007jkK (1:4575)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-BxK.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1rpw (1:4578)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-Dvw.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1oEP (1:4558)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-TJP.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsicF (1:4648)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupyj8k3uR (XTyHJFKB8vfhRQtdGRYj8K)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoo7u (1:4678)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse8008vs (1:4679)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-NgX.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group297793nw (1:4683)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-yJw.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsHhH (1:4654)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801QX1 (1:4658)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804LfZ (1:4659)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // jacobjonesgUX (1:4660)
                                                          'Jacob Jones',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorbLb (1:4661)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298007pj (1:4662)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001do5 (1:4663)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-7mR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50059mR (1:4666)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-gNs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006Tn7 (1:4669)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-qju.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007PQs (1:4672)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-Zgs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1KJX (1:4675)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-T6F.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1rZM (1:4655)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-8U7.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsydy (1:4745)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogrouprezbtkw (XTyHm4spWgmWUMGgXdREzB)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoSGf (1:4775)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800NRD (1:4776)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-8WK.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779gwh (1:4780)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-mfM.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsKzf (1:4751)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801T5H (1:4755)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804yJX (1:4756)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // courtneyhenry7Qj (1:4757)
                                                          'Courtney Henry',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdoloreQf (1:4758)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800ap7 (1:4759)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001Jk7 (1:4760)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-TpT.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50052RD (1:4763)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-aJs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006x3y (1:4766)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-nvT.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007H6F (1:4769)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-9LT.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1Cyu (1:4772)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-uLb.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1YXy (1:4752)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-Vh1.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetails3zX (1:4842)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupczqbBL3 (XTyJDdwt352Gk3pG2CcZQB)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo7jV (1:4872)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800fW7 (1:4873)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-z2K.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779naj (1:4877)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-69D.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsc3y (1:4848)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801Kj5 (1:4852)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804T4b (1:4853)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // albertfloresbAo (1:4854)
                                                          'Albert Flores',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorKsV (1:4855)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298004aB (1:4856)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001yx3 (1:4857)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-Jgw.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50056mm (1:4860)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-Jhu.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006DbV (1:4863)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-vTH.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50079EF (1:4866)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-Ku1.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1fiP (1:4869)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-4HM.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1Qfy (1:4849)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-1pb.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsjiF (1:4939)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroups4vm5GK (XTyJhhySfiMKhBNi8Zs4VM)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photopUo (1:4969)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-TYB.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779w3d (1:4974)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-1m1.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsmHZ (1:4945)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801H11 (1:4949)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804cJB (1:4950)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // jacobjoneskfH (1:4951)
                                                          'Jacob Jones',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorJB1 (1:4952)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800EaT (1:4953)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001j1R (1:4954)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-WXh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50053H1 (1:4957)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-NJ3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006mD1 (1:4960)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-ddy.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007Ut7 (1:4963)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-JTR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1uyR (1:4966)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-UXR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1r7y (1:4946)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-PeP.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsN6K (1:5036)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupkznkHUB (XTyK8XbRETgkWD4wEiKznK)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photopj1 (1:5066)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-YEs.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779XtK (1:5071)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-NCP.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsZa7 (1:5042)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801Fhq (1:5046)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804NXZ (1:5047)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // courtneyhenryVs5 (1:5048)
                                                          'Courtney Henry',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorqg3 (1:5049)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800BV1 (1:5050)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001uA7 (1:5051)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-kSs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005pXy (1:5054)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-uZ1.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006kAj (1:5057)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-cUf.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007rzT (1:5060)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-YnT.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1BWw (1:5063)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-p7y.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1j2f (1:5043)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-PYj.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsFmh (1:5133)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupt92wzUP (XTyKYmQ2oziQAM9Nt3t92w)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photojB5 (1:5163)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-iqV.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779Drw (1:5168)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-r6K.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsEn3 (1:5139)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801YXq (1:5143)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804t5u (1:5144)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // albertfloresRLj (1:5145)
                                                          'Albert Flores',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorNFy (1:5146)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800JvK (1:5147)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001EJB (1:5148)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-VSP.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005Mdh (1:5151)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-nz3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006HGT (1:5154)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-obD.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007Bsd (1:5157)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-mZ9.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder17mH (1:5160)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-irs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1TaF (1:5140)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-yKV.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsPD1 (1:5230)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupfst37Pu (XTyKyLXRXNCnC918DZfst3)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo3oM (1:5260)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-t2B.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779kBy (1:5265)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-gCP.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsmsm (1:5236)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801tSb (1:5240)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame298041XD (1:5241)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // jacobjones8bq (1:5242)
                                                          'Jacob Jones',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorspK (1:5243)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800DNP (1:5244)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001w3V (1:5245)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-6Fh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005F4B (1:5248)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-etw.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006AS3 (1:5251)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-F8B.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007HmZ (1:5254)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-SH5.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder12DM (1:5257)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-b91.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1xco (1:5237)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-suZ.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsVMq (1:5327)
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroup8pb1SH5 (XTyLQA9Q67YD1AhMKi8pB1)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoaeB (1:5357)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-UsR.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779VFM (1:5362)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-Sjq.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailshsD (1:5333)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame2980128o (1:5337)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame298049jD (1:5338)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // courtneyhenryHqR (1:5339)
                                                          'Courtney Henry',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorEVm (1:5340)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800yCT (1:5341)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001tKR (1:5342)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-6Wj.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005ztF (1:5345)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-qJw.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50067hy (1:5348)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-CDM.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007Enb (1:5351)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-uvX.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1xib (1:5354)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-3xB.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1hRH (1:5334)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // homeindicatorDeX (1:5447)
                    left: 0*fem,
                    top: 429*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(121*fem, 21*fem, 120*fem, 8*fem),
                      width: 375*fem,
                      height: 34*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                      child: Center(
                        // homeindicator8Wb (I1:5447;5:3093)
                        child: SizedBox(
                          width: double.infinity,
                          height: 5*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
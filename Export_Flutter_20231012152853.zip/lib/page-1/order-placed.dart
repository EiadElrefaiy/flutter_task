import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // orderplacedWPq (1:8200)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroup5mhh27H (XTz6u3ff74gbmj9tod5mhh)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              height: 115*fem,
              child: Stack(
                children: [
                  Positioned(
                    // statusbar8w1 (1:8305)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 115*fem,
                        child: Image.asset(
                          'assets/page-1/images/status-bar-8dM.png',
                          width: 375*fem,
                          height: 115*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // checkoutdMy (1:8317)
                    left: 148*fem,
                    top: 53*fem,
                    child: Align(
                      child: SizedBox(
                        width: 80*fem,
                        height: 42*fem,
                        child: Text(
                          'Checkout',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Montserrat',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w700,
                            height: 2.625*ffem/fem,
                            letterSpacing: -0.2399999946*fem,
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupuvkhVf5 (XTz6ysrwZgNCBfypMBUvKh)
              width: double.infinity,
              height: 681*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29931F8T (1:8201)
                    left: 22.5*fem,
                    top: 0*fem,
                    child: Container(
                      width: 330*fem,
                      height: 570*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupvdpb9jd (XTz7986Y4cey3VuXpaVDpb)
                            margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 63*fem),
                            width: 208*fem,
                            height: 202*fem,
                            child: Image.asset(
                              'assets/page-1/images/auto-group-vdpb.png',
                              width: 208*fem,
                              height: 202*fem,
                            ),
                          ),
                          Container(
                            // flicitations3q1 (1:8295)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 29*fem),
                            constraints: BoxConstraints (
                              maxWidth: 197*fem,
                            ),
                            child: Text(
                              'Order Successfully \nPlaced !',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Montserrat',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.2175*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // vousavezavecsuccucK (1:8296)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 58*fem),
                            constraints: BoxConstraints (
                              maxWidth: 330*fem,
                            ),
                            child: Text(
                              'Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat . ',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // bntnRD (1:8300)
                            margin: EdgeInsets.fromLTRB(44.5*fem, 0*fem, 45.5*fem, 14*fem),
                            width: double.infinity,
                            height: 48*fem,
                            decoration: BoxDecoration (
                              color: Color(0xff4b0000),
                              borderRadius: BorderRadius.circular(24*fem),
                            ),
                            child: Center(
                              child: Text(
                                'COMFIRM PAYEMENT',
                                style: SafeGoogleFont (
                                  'Montserrat',
                                  fontSize: 16*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.2175*ffem/fem,
                                  letterSpacing: -0.2399999946*fem,
                                  color: Color(0xffffffff),
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // bntdRq (1:8297)
                            margin: EdgeInsets.fromLTRB(45.5*fem, 0*fem, 44.5*fem, 0*fem),
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom (
                                padding: EdgeInsets.zero,
                              ),
                              child: Container(
                                width: double.infinity,
                                height: 48*fem,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xffffffff)),
                                  color: Color(0xff4b0000),
                                  borderRadius: BorderRadius.circular(24*fem),
                                ),
                                child: Center(
                                  child: Text(
                                    'SAVE & COMFIRM',
                                    style: SafeGoogleFont (
                                      'Montserrat',
                                      fontSize: 16*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.2175*ffem/fem,
                                      letterSpacing: -0.2399999946*fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1016T9y (1:8303)
                    left: 0*fem,
                    top: 567*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 114*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // homeindicatorNXq (I1:8304;5:3093)
                    left: 121*fem,
                    top: 668*fem,
                    child: Align(
                      child: SizedBox(
                        width: 134*fem,
                        height: 5*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(100*fem),
                            color: Color(0xff000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
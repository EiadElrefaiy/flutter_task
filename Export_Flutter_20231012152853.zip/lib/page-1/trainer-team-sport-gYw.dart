import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // trainerteamsportyP5 (1:6369)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // statusbarrSs (1:6522)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-21-kjH.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // statusbariphonexornewervxX (1:6564)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: 375*fem,
                    height: 44*fem,
                    child: Image.asset(
                      'assets/page-1/images/status-bar-iphone-x-or-newer-CtP.png',
                      width: 375*fem,
                      height: 44*fem,
                    ),
                  ),
                  Container(
                    // autogroupsihmDRq (XTycShQtQkkhdXNM2YsihM)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 26*fem, 0*fem),
                    width: double.infinity,
                    height: 39*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // arrowbackios4vb9 (1:6524)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 88*fem, 0*fem),
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              width: 24*fem,
                              height: 24*fem,
                              child: Image.asset(
                                'assets/page-1/images/arrowbackios-4-Fc3.png',
                                width: 24*fem,
                                height: 24*fem,
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // frame29805DaF (1:6527)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 97*fem, 0*fem),
                          width: 120*fem,
                          height: double.infinity,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame29810wm9 (1:6528)
                                width: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // jennywilsontwH (1:6529)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                                      child: Text(
                                        'Jenny Wilson',
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w600,
                                          height: 1.5*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // flagofegypt1b51 (1:6530)
                                      width: 21*fem,
                                      height: 14*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/flagofegypt-1.png',
                                        width: 21*fem,
                                        height: 14*fem,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Text(
                                // footballtrainerVw5 (1:6563)
                                'Football Trainer',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.5*ffem/fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // morevert1dnP (1:6565)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                          width: 4*fem,
                          height: 16*fem,
                          child: Image.asset(
                            'assets/page-1/images/morevert-1.png',
                            width: 4*fem,
                            height: 16*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupcrh1Y8f (XTyZMNQ2SnByCfBQS5CRh1)
              width: 436*fem,
              height: 681*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29932GqM (1:6370)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 436*fem,
                      height: 664*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // videosportyjm (1:6371)
                            left: 16*fem,
                            top: 514*fem,
                            child: Container(
                              width: 343*fem,
                              height: 150*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // placeoftrainig6Jb (1:6372)
                                    margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 12*fem),
                                    child: Text(
                                      'Place of Trainig',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w500,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // frame29927DPD (1:6373)
                                    width: double.infinity,
                                    height: 114*fem,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Container(
                                          // frame29929AJT (1:6374)
                                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                          height: double.infinity,
                                          child: Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // videoJfZ (1:6375)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                                                height: double.infinity,
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // unsplash4mrqv9gcuhqSWs (1:6376)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                                      width: 104*fem,
                                                      height: 72*fem,
                                                      child: ClipRRect(
                                                        borderRadius: BorderRadius.circular(4*fem),
                                                        child: Image.asset(
                                                          'assets/page-1/images/unsplash-4mrqv9gcuhq-GPq.png',
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                    ),
                                                    Container(
                                                      // hallandalebeachwyR (1:6377)
                                                      constraints: BoxConstraints (
                                                        maxWidth: 65*fem,
                                                      ),
                                                      child: Text(
                                                        'Hallandale Beach',
                                                        style: SafeGoogleFont (
                                                          'Poppins',
                                                          fontSize: 12*ffem,
                                                          fontWeight: FontWeight.w400,
                                                          height: 1.5*ffem/fem,
                                                          color: Color(0xff000000),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                // videogAK (1:6378)
                                                decoration: BoxDecoration (
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Container(
                                                      // unsplash4mrqv9gcuhqYCX (1:6379)
                                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                                      width: 104*fem,
                                                      height: 72*fem,
                                                      child: ClipRRect(
                                                        borderRadius: BorderRadius.circular(4*fem),
                                                        child: Image.asset(
                                                          'assets/page-1/images/unsplash-4mrqv9gcuhq.png',
                                                          fit: BoxFit.cover,
                                                        ),
                                                      ),
                                                    ),
                                                    Text(
                                                      // painesvilleSoh (1:6380)
                                                      'Painesville',
                                                      style: SafeGoogleFont (
                                                        'Poppins',
                                                        fontSize: 12*ffem,
                                                        fontWeight: FontWeight.w400,
                                                        height: 1.5*ffem/fem,
                                                        color: Color(0xff000000),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Container(
                                          // videonsZ (1:6382)
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(4*fem),
                                          ),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Container(
                                                // unsplash4mrqv9gcuhqYbq (1:6383)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                                width: 103*fem,
                                                height: 72*fem,
                                                child: ClipRRect(
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                  child: Image.asset(
                                                    'assets/page-1/images/unsplash-4mrqv9gcuhq-M2X.png',
                                                    fit: BoxFit.cover,
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                // lebanonTTu (1:6384)
                                                'Lebanon',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 12*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // picktimeb4K (1:6385)
                            left: 16*fem,
                            top: 378*fem,
                            child: Container(
                              width: 420*fem,
                              height: 120*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    // traineravailablescheduleJjR (1:6386)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 12*fem),
                                    child: Text(
                                      'Trainer available schedule  ',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // group298241dq (1:6388)
                                    width: double.infinity,
                                    height: 84*fem,
                                    decoration: BoxDecoration (
                                      borderRadius: BorderRadius.circular(4*fem),
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // autogroupqdwpMBu (XTya1w86qF32uoqxrzqDWP)
                                          width: 132*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame7111VZ1 (1:6389)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 38*fem,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffe6e6e6)),
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    '9:00 - 9:15 am',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame7111Mr7 (1:6392)
                                                width: double.infinity,
                                                height: 38*fem,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffe6e6e6)),
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    '9:00 - 9:15 am',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 12*fem,
                                        ),
                                        Container(
                                          // autogroupakwkqmH (XTya86cVqCZYpMo7BGAkWK)
                                          width: 132*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame7112nRd (1:6390)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 38*fem,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffe6e6e6)),
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    '9:00 - 9:15 am',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame7112g1D (1:6393)
                                                width: double.infinity,
                                                height: 38*fem,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffe6e6e6)),
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    '9:00 - 9:15 am',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          width: 12*fem,
                                        ),
                                        Container(
                                          // autogroupbux7ABH (XTyaEWbUgXw7W9ajGABUx7)
                                          width: 132*fem,
                                          height: double.infinity,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            children: [
                                              Container(
                                                // frame7112VzF (1:6391)
                                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                                                width: double.infinity,
                                                height: 38*fem,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffe6e6e6)),
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    '9:00 - 9:15 am',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Container(
                                                // frame7112b1h (1:6394)
                                                width: double.infinity,
                                                height: 38*fem,
                                                decoration: BoxDecoration (
                                                  border: Border.all(color: Color(0xffe6e6e6)),
                                                  color: Color(0xffffffff),
                                                  borderRadius: BorderRadius.circular(4*fem),
                                                ),
                                                child: Center(
                                                  child: Text(
                                                    '9:00 - 9:15 am',
                                                    style: SafeGoogleFont (
                                                      'Poppins',
                                                      fontSize: 12*ffem,
                                                      fontWeight: FontWeight.w400,
                                                      height: 1.5*ffem/fem,
                                                      color: Color(0xff000000),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // group29805ULP (1:6395)
                            left: 118*fem,
                            top: 0*fem,
                            child: Container(
                              width: 139*fem,
                              height: 202*fem,
                              child: Stack(
                                children: [
                                  Positioned(
                                    // ellipse800NAs (1:6396)
                                    left: 0*fem,
                                    top: 0*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 139*fem,
                                        height: 193.42*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ellipse-800-PGT.png',
                                          width: 139*fem,
                                          height: 193.42*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    // group29779DxB (1:6400)
                                    left: 60*fem,
                                    top: 179.5073242188*fem,
                                    child: Align(
                                      child: SizedBox(
                                        width: 19.46*fem,
                                        height: 22.49*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/group-29779-XtT.png',
                                          width: 19.46*fem,
                                          height: 22.49*fem,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // loremipsumdolorsitametdolorlor (1:6462)
                            left: 16*fem,
                            top: 273*fem,
                            child: Align(
                              child: SizedBox(
                                width: 326*fem,
                                height: 36*fem,
                                child: Text(
                                  'lorem ipsum dolor sit amet dolor lorem ipsum dolor sit amet dolor lorem ipsum dolor sit amet dolor ...',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group298214LX (1:6463)
                            left: 16*fem,
                            top: 244*fem,
                            child: Container(
                              width: 343*fem,
                              height: 21*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // frame29801aJs (1:6464)
                                    margin: EdgeInsets.fromLTRB(0*fem, 2*fem, 170*fem, 1*fem),
                                    padding: EdgeInsets.fromLTRB(1.5*fem, 1.5*fem, 1.5*fem, 2.25*fem),
                                    height: double.infinity,
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // starpurple5001t4f (1:6465)
                                          width: 15*fem,
                                          height: 14.25*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/starpurple500-1-K6f.png',
                                            width: 15*fem,
                                            height: 14.25*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 7*fem,
                                        ),
                                        Container(
                                          // starpurple5005CLF (1:6468)
                                          width: 15*fem,
                                          height: 14.25*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/starpurple500-5-NNK.png',
                                            width: 15*fem,
                                            height: 14.25*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 7*fem,
                                        ),
                                        Container(
                                          // starpurple5006Wrj (1:6471)
                                          width: 15*fem,
                                          height: 14.25*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/starpurple500-6-MiF.png',
                                            width: 15*fem,
                                            height: 14.25*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 7*fem,
                                        ),
                                        Container(
                                          // starpurple5007Enj (1:6474)
                                          width: 15*fem,
                                          height: 14.25*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/starpurple500-7-UNK.png',
                                            width: 15*fem,
                                            height: 14.25*fem,
                                          ),
                                        ),
                                        SizedBox(
                                          width: 7*fem,
                                        ),
                                        Container(
                                          // starborder1xCw (1:6477)
                                          width: 15*fem,
                                          height: 14.25*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/starborder-1-yVZ.png',
                                            width: 15*fem,
                                            height: 14.25*fem,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Text(
                                    // hourgud (1:6480)
                                    '\$50/hour',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // frame29809dK5 (1:6481)
                            left: 16*fem,
                            top: 218*fem,
                            child: Container(
                              width: 141*fem,
                              height: 24*fem,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // jennywilson9HR (1:6482)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                    child: Text(
                                      'Jenny Wilson',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                  Container(
                                    // flagofegypt1dyH (1:6483)
                                    width: 21*fem,
                                    height: 14*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/flagofegypt-1-Bom.png',
                                      width: 21*fem,
                                      height: 14*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // slider9gj (I1:6516;120:5512)
                            left: 0*fem,
                            top: 317*fem,
                            child: Container(
                              width: 375*fem,
                              height: 47*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // autogroupuug3fuy (XTyaqfFaSBZBtNVQqmuug3)
                                    width: double.infinity,
                                    height: 45*fem,
                                    decoration: BoxDecoration (
                                      color: Color(0xffffffff),
                                    ),
                                    child: Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // scheduleQMm (I1:6516;120:6070)
                                          width: 188*fem,
                                          height: double.infinity,
                                          decoration: BoxDecoration (
                                            color: Color(0xffffffff),
                                          ),
                                          child: Center(
                                            child: Text(
                                              'Schedule',
                                              style: SafeGoogleFont (
                                                'Poppins',
                                                fontSize: 14*ffem,
                                                fontWeight: FontWeight.w400,
                                                height: 1.5*ffem/fem,
                                                color: Color(0xff000000),
                                              ),
                                            ),
                                          ),
                                        ),
                                        TextButton(
                                          // achievement6Eb (I1:6516;120:6071)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: 187*fem,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              color: Color(0xffffffff),
                                            ),
                                            child: Center(
                                              child: Text(
                                                'Achievement',
                                                style: SafeGoogleFont (
                                                  'Poppins',
                                                  fontSize: 14*ffem,
                                                  fontWeight: FontWeight.w400,
                                                  height: 1.5*ffem/fem,
                                                  color: Color(0xff000000),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Container(
                                    // autogroupf1j5afZ (XTyazezb5jzuxxaeYYF1j5)
                                    width: double.infinity,
                                    height: 2*fem,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // rectangle1016wFD (1:6517)
                    left: 0*fem,
                    top: 567*fem,
                    child: Align(
                      child: SizedBox(
                        width: 375*fem,
                        height: 114*fem,
                        child: Container(
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // buttonrsy (1:6518)
                    left: 16*fem,
                    top: 567*fem,
                    child: Container(
                      width: 343*fem,
                      height: 48*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff4b0000),
                        borderRadius: BorderRadius.circular(8*fem),
                      ),
                      child: Center(
                        child: Text(
                          'BOOKING NOW',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            color: Color(0xffffffff),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // homeindicatorKmZ (1:6521)
                    left: 0*fem,
                    top: 647*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(121*fem, 21*fem, 120*fem, 8*fem),
                      width: 375*fem,
                      height: 34*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                      child: Center(
                        // homeindicator2vs (I1:6521;5:3093)
                        child: SizedBox(
                          width: double.infinity,
                          height: 5*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // trainerteamsportspb (1:5458)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbarx5M (1:5459)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-21-MvP.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // statusbariphonexornewer3Mh (1:5468)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: 375*fem,
                    height: 44*fem,
                    child: Image.asset(
                      'assets/page-1/images/status-bar-iphone-x-or-newer-TPm.png',
                      width: 375*fem,
                      height: 44*fem,
                    ),
                  ),
                  Container(
                    // autogroupixtfLbh (XTyVtJWPR344v3Gotaixtf)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextButton(
                          // arrowbackios4s5q (1:5464)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/arrowbackios-4-ZCB.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 119*fem,
                        ),
                        Text(
                          // trainerYhm (1:5467)
                          'Trainer',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        SizedBox(
                          width: 119*fem,
                        ),
                        Container(
                          // autogroupv7fm4AK (XTyVyYreHwp5J3ps3rv7Fm)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-v7fm.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouplgkpNwh (XTyQXCwkX7DPr3eiqKLGkP)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
              width: double.infinity,
              height: 241*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group29809hj5 (1:5473)
                    left: 0*fem,
                    top: 45*fem,
                    child: Container(
                      width: 375*fem,
                      height: 196*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupomsfd6w (XTyQh7puHiRdTB93h4omSF)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            width: double.infinity,
                            height: 180*fem,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                fit: BoxFit.cover,
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-1010-bg-UAB.png',
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // frame29799Jym (1:5475)
                            margin: EdgeInsets.fromLTRB(160*fem, 0*fem, 159*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse8032Py (1:5476)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0xff4b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse804kKy (1:5477)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse805Gp7 (1:5478)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse806QQX (1:5479)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // group7166kjH (1:5483)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 375*fem,
                      height: 47*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroup4pyr5Fm (XTyQy7NFmpYhNSdgwY4PyR)
                            padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 17*fem, 6*fem),
                            width: double.infinity,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // individualBJo (1:5485)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Text(
                                      'Individual',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 34*fem,
                                ),
                                Container(
                                  // teamsportqu9 (1:5486)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Text(
                                      'Team Sport',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 34*fem,
                                ),
                                Container(
                                  // autogroupbvit9Q3 (XTyR5h1dC59dF4JxsXBviT)
                                  width: 34*fem,
                                  height: double.infinity,
                                  child: Text(
                                    'Gym',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: 34*fem,
                                ),
                                Container(
                                  // exsporterb (1:5488)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: Text(
                                    'EX Sport',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupadsmaVM (XTyREBmU8suFmAjF32Adsm)
                            margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                            width: double.infinity,
                            height: 2*fem,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogrouppg5m7VH (XTyRVRq54rVBLiiSybPg5M)
              width: double.infinity,
              height: 463*fem,
              child: Stack(
                children: [
                  Positioned(
                    // homeindicatorFrP (1:5472)
                    left: 0*fem,
                    top: 429*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(121*fem, 21*fem, 120*fem, 8*fem),
                      width: 375*fem,
                      height: 34*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                      child: Center(
                        // homeindicatorko9 (I1:5472;5:3093)
                        child: SizedBox(
                          width: double.infinity,
                          height: 5*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame29803HYB (1:5493)
                    left: 16*fem,
                    top: 0*fem,
                    child: Container(
                      width: 343*fem,
                      height: 453*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // gymtrainerPr7 (1:5494)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                            child: Text(
                              'Gym Trainer',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // frame29802hbu (1:5495)
                            width: double.infinity,
                            height: 413*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // trainerdetailsRH1 (1:5496)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupebbdx23 (XTyRwVuxtV3r3wb4vuEbbd)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // phototRV (1:5526)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800RgK (1:5527)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-1fd.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group2977996X (1:5531)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-t15.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsaBq (1:5502)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801VJo (1:5506)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804Dkb (1:5507)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // eleanorpenaZJf (1:5508)
                                                          'Eleanor Pena',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorJ1M (1:5509)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800EQo (1:5510)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001MkK (1:5511)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-Nij.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50054ej (1:5514)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-wKm.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006aNB (1:5517)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-oC3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple500777D (1:5520)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-t2b.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1q3D (1:5523)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-yi7.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1MnF (1:5503)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-UDD.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsHA7 (1:5593)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupckr9pA3 (XTySPjfFH2qswzMLjJCKR9)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoxX9 (1:5623)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800J5D (1:5624)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-jHh.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779CwH (1:5628)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-Bd1.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsS4w (1:5599)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801x3H (1:5603)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804FYB (1:5604)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // guyhawkinszEs (1:5605)
                                                          'Guy Hawkins',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorigf (1:5606)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800eqD (1:5607)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001ycb (1:5608)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-3aP.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005hHh (1:5611)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-6oh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50061pB (1:5614)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-qts.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple500799h (1:5617)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-M9H.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1GEK (1:5620)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-bUb.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1zw1 (1:5600)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-s3d.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsvJs (1:5690)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupderjFc3 (XTySpe7R8EnzMRzPkzDerj)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoCGP (1:5720)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse8008fq (1:5721)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-U5d.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779f9y (1:5725)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-kB9.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsgKy (1:5696)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801bC3 (1:5700)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame298047RH (1:5701)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // wadewarrenFGb (1:5702)
                                                          'Wade Warren',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorbLT (1:5703)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800KnF (1:5704)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001FR1 (1:5705)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-9RZ.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005Ans (1:5708)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-BV9.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006h27 (1:5711)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-XCb.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007Qx7 (1:5714)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-Bsu.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder19Pu (1:5717)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-3PM.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle164F (1:5697)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-X3V.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsbmh (1:5787)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupszzdjN7 (XTyTF8QcZ9fgnouKAxSzZD)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo5B5 (1:5817)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse8001aX (1:5818)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-6nB.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779KLK (1:5822)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-K35.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsxeB (1:5793)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801sm9 (1:5797)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804QWB (1:5798)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // eleanorpenawm1 (1:5799)
                                                          'Eleanor Pena',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorVGj (1:5800)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800d83 (1:5801)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001MJw (1:5802)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-nvs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005GB1 (1:5805)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-SbZ.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006nQF (1:5808)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-c71.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007uzf (1:5811)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-bR9.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1qdR (1:5814)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-LXh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle19u1 (1:5794)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-LUf.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsTeo (1:5884)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroup6lmvBqh (XTyTenPs9UPZJ4MyMV6LmV)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photov2b (1:5914)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-zZu.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group297791pj (1:5919)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-Fwd.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsRdZ (1:5890)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame298018ns (1:5894)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804fXu (1:5895)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // guyhawkinsCnj (1:5896)
                                                          'Guy Hawkins',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorj1y (1:5897)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298003YT (1:5898)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001ZWo (1:5899)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-CbH.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50055EF (1:5902)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-A8P.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006CZm (1:5905)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-PU3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007Xrw (1:5908)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-bpK.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1eAs (1:5911)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-wgK.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1yiw (1:5891)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-AtX.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetails6Yf (1:5981)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupkrntdYb (XTyU827UwXZnK4UAEQkrNT)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoaCw (1:6011)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-x1d.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779sC3 (1:6016)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-d43.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsgvB (1:5987)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801oE7 (1:5991)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame298048GP (1:5992)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // wadewarrenGdV (1:5993)
                                                          'Wade Warren',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorQUo (1:5994)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298009SP (1:5995)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001G1D (1:5996)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-snP.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005Npw (1:5999)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-pSs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006h6X (1:6002)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-jAF.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007pS3 (1:6005)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-K9H.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1jZ1 (1:6008)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-xLX.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1H4j (1:5988)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-8zb.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetails1WX (1:6078)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupspmhLYo (XTyUYLkHoXD7ZcVRoHsPmh)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo5FV (1:6108)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-J9V.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779NkP (1:6113)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-qkK.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsCzK (1:6084)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801jUT (1:6088)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804fN7 (1:6089)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // eleanorpenaoUK (1:6090)
                                                          'Eleanor Pena',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolork8f (1:6091)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800sj5 (1:6092)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001zHu (1:6093)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-Nzj.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005iDu (1:6096)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-Tqy.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006R8K (1:6099)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-MR1.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007KzP (1:6102)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-Vzo.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1rUX (1:6105)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-pA3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1C2b (1:6085)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-hef.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsiWj (1:6175)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupywawefH (XTyUxfP6fWrSpAWhNAywAw)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoaJ3 (1:6205)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-U9V.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group297795kb (1:6210)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-jRZ.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsi2s (1:6181)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801Rhy (1:6185)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804kkF (1:6186)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // guyhawkinsUw9 (1:6187)
                                                          'Guy Hawkins',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorDdq (1:6188)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800Yw1 (1:6189)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001UJs (1:6190)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-2yu.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005zHD (1:6193)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-EM5.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50067cj (1:6196)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-QTq.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007Sf1 (1:6199)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-d59.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1yew (1:6202)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-3dR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1v4P (1:6182)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-wfd.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsEas (1:6272)
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupesio6d5 (XTyVP4r6oy7Tf8Unrbesio)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photodN7 (1:6302)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-fXd.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779wdh (1:6307)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-xQP.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsAFZ (1:6278)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801gjh (1:6282)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804cdM (1:6283)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // wadewarrenMaw (1:6284)
                                                          'Wade Warren',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorJWB (1:6285)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800eK9 (1:6286)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001NF9 (1:6287)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-Ryy.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005Hsu (1:6290)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-Ttj.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple500613D (1:6293)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-ECX.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007vR5 (1:6296)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-rXZ.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1FTM (1:6299)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-2ud.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1bGK (1:6279)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-JCo.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
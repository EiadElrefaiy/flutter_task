import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // trainerindividualYJT (1:6568)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffffffff),
          borderRadius: BorderRadius.circular(20*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // statusbarCP1 (1:7466)
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/rectangle-21-KmZ.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // statusbariphonexornewerszw (1:7478)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                    width: 375*fem,
                    height: 44*fem,
                    child: Image.asset(
                      'assets/page-1/images/status-bar-iphone-x-or-newer-Tqh.png',
                      width: 375*fem,
                      height: 44*fem,
                    ),
                  ),
                  Container(
                    // autogroupdytxyHH (XTymoGAAuvHSYpvcaudYtX)
                    margin: EdgeInsets.fromLTRB(16*fem, 0*fem, 16*fem, 0*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        TextButton(
                          // arrowbackios4UUw (1:7471)
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Container(
                            width: 24*fem,
                            height: 24*fem,
                            child: Image.asset(
                              'assets/page-1/images/arrowbackios-4-r2T.png',
                              width: 24*fem,
                              height: 24*fem,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 119*fem,
                        ),
                        Text(
                          // trainera2B (1:7474)
                          'Trainer',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 16*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                        ),
                        SizedBox(
                          width: 119*fem,
                        ),
                        Container(
                          // autogrouphtxpGvb (XTymtLr3Dup5k1b1u6htxP)
                          width: 24*fem,
                          height: 24*fem,
                          child: Image.asset(
                            'assets/page-1/images/auto-group-htxp.png',
                            width: 24*fem,
                            height: 24*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupwnvkC3Z (XTyczmKnfRcX4UJTT2wNvK)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
              width: double.infinity,
              height: 241*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group29809VoM (1:7445)
                    left: 0*fem,
                    top: 45*fem,
                    child: Container(
                      width: 375*fem,
                      height: 196*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // autogroupcsmhCBy (XTydB6MurKuAdfWuvWCsMH)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
                            width: double.infinity,
                            height: 180*fem,
                            decoration: BoxDecoration (
                              image: DecorationImage (
                                image: AssetImage (
                                  'assets/page-1/images/rectangle-1010-bg-XiX.png',
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // frame297996o9 (1:7447)
                            margin: EdgeInsets.fromLTRB(160*fem, 0*fem, 159*fem, 0*fem),
                            width: double.infinity,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // ellipse803d2P (1:7448)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0xff4b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse804LBh (1:7449)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse805FZZ (1:7450)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                                SizedBox(
                                  width: 8*fem,
                                ),
                                Container(
                                  // ellipse806nZV (1:7451)
                                  width: 8*fem,
                                  height: 8*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(4*fem),
                                    color: Color(0x664b0000),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // sliderLb1 (1:7456)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 375*fem,
                      height: 47*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            // autogroupyskbfdH (XTydVFWKiN1yyfb3B7yskb)
                            padding: EdgeInsets.fromLTRB(16*fem, 12*fem, 16*fem, 6*fem),
                            width: double.infinity,
                            height: 45*fem,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                            ),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // autogroupm1buB5q (XTydbLAXRrvpHobMZqm1bu)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 40*fem, 0*fem),
                                  width: 68*fem,
                                  height: double.infinity,
                                  child: Text(
                                    'Individual',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // teamsportf11 (1:7459)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 40*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Text(
                                      'Team Sport',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // gymkHM (1:7460)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 23*fem, 6*fem),
                                  child: TextButton(
                                    onPressed: () {},
                                    style: TextButton.styleFrom (
                                      padding: EdgeInsets.zero,
                                    ),
                                    child: Text(
                                      'Gym',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 14*ffem,
                                        fontWeight: FontWeight.w400,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  // exsport3nF (1:7461)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6*fem),
                                  child: Text(
                                    'EX Sport',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w400,
                                      height: 1.5*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // autogroupt7q3Aby (XTydkk4WViSxLTQitKt7Q3)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 16*fem, 0*fem),
                            width: 235*fem,
                            height: 2*fem,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupfyetWA3 (XTye2uGFYjoPSYo1ytFYET)
              width: double.infinity,
              height: 466*fem,
              child: Stack(
                children: [
                  Positioned(
                    // frame29803F7d (1:6569)
                    left: 4*fem,
                    top: 0*fem,
                    child: Container(
                      width: 343*fem,
                      height: 453*fem,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // individualtrainerAEb (1:6570)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                            child: Text(
                              'Individual Trainer',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 16*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // frame29802seo (1:6571)
                            width: double.infinity,
                            height: 413*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // trainerdetailsnFy (1:6572)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupttvqJk7 (XTyeVPW7nfSU7qPmYutTVq)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoeJB (1:6602)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800BJ7 (1:6603)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-RNo.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779V3u (1:6607)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-zbZ.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailstrj (1:6578)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame298011RZ (1:6582)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804LTq (1:6583)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // ralphedwardssTm (1:6584)
                                                          'Ralph Edwards',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolor1Zy (1:6585)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800YZu (1:6586)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001Twm (1:6587)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-H75.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005Zju (1:6590)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-oEX.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006gpX (1:6593)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-TbD.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007ou9 (1:6596)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-6jR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder17uq (1:6599)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-ptf.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1fAf (1:6579)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-hkj.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsBPu (1:6669)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupxnmd7HZ (XTyewsjz2b5Yo7zX7wXNmD)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoF8s (1:6699)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800yaf (1:6700)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-Jes.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group297796QP (1:6704)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-DoD.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsWj1 (1:6675)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801DtK (1:6679)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804ZBV (1:6680)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // courtneyhenryHNP (1:6681)
                                                          'Courtney Henry',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorbP5 (1:6682)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298007cK (1:6683)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001q2X (1:6684)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-nwZ.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005wbM (1:6687)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-u4K.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50064R5 (1:6690)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-vn3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007yY3 (1:6693)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-xXH.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1hiw (1:6696)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-Qib.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1dsV (1:6676)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-Bdy.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsmD1 (1:6766)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupnjhvgqm (XTyfPwpsrDeDWLs95FNJHV)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo2ej (1:6796)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800AW3 (1:6797)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-fh1.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779H4s (1:6801)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-PQb.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsVRq (1:6772)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801oxK (1:6776)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804LST (1:6777)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // janecooperfzX (1:6778)
                                                          'Jane Cooper',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorDWF (1:6779)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298009eo (1:6780)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001ft3 (1:6781)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-DxK.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005nBy (1:6784)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-AwR.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006u1h (1:6787)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-pBq.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007E3y (1:6790)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-Xyy.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1M8b (1:6793)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-F83.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1t8X (1:6773)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-znb.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsnjh (1:6863)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupuqgjidM (XTyfpGTgiDHYkttQe8Uqgj)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoemu (1:6893)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            width: double.infinity,
                                            height: double.infinity,
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  // ellipse800avT (1:6894)
                                                  left: 0*fem,
                                                  top: 0*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 64*fem,
                                                      height: 88.09*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/ellipse-800-4hD.png',
                                                        width: 64*fem,
                                                        height: 88.09*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  // group29779uSw (1:6898)
                                                  left: 27.5200195312*fem,
                                                  top: 81.7556152344*fem,
                                                  child: Align(
                                                    child: SizedBox(
                                                      width: 8.96*fem,
                                                      height: 10.24*fem,
                                                      child: Image.asset(
                                                        'assets/page-1/images/group-29779-add.png',
                                                        width: 8.96*fem,
                                                        height: 10.24*fem,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsi9V (1:6869)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801pyD (1:6873)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804A1V (1:6874)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // ralphedwardsuDy (1:6875)
                                                          'Ralph Edwards',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolor3LB (1:6876)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800NNT (1:6877)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001Vhy (1:6878)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-1vf.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005c1u (1:6881)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-rHD.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006XPm (1:6884)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-WKh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007rB9 (1:6887)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-XoM.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1mou (1:6890)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-MDh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1KKd (1:6870)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-28P.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailse71 (1:6960)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupcxumN31 (XTygGAtBxvcrHHsNkMCxum)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // phototn3 (1:6990)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-DsD.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779PD1 (1:6995)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-7WF.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsp3R (1:6966)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame298018K1 (1:6970)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804TMH (1:6971)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // courtneyhenryzs1 (1:6972)
                                                          'Courtney Henry',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorLR5 (1:6973)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800ruD (1:6974)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple50019NX (1:6975)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-xV5.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50054Eb (1:6978)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-eJb.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006aTq (1:6981)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-kFH.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007uFD (1:6984)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-DTu.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder12aj (1:6987)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-qjV.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1AS3 (1:6967)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-1eo.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsGzs (1:7057)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupu4rkbnF (XTygkA5ZK7LDe1UzwAu4rK)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photojdZ (1:7087)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-mqq.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779chM (1:7092)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-Rh1.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsdsM (1:7063)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801jfV (1:7067)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804TrP (1:7068)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // janecooperzLX (1:7069)
                                                          'Jane Cooper',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolor8Bq (1:7070)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame298004LP (1:7071)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001Nby (1:7072)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-Muh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005gsZ (1:7075)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-BiP.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006cWK (1:7078)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-qzP.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007LBR (1:7081)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-5Wo.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1G55 (1:7084)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-Kvo.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1QBH (1:7064)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-zPq.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsXWo (1:7154)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupdc5mStf (XTyhC4W4ZpfXAQTy3PdC5M)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photoPJ7 (1:7184)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-ZU3.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779HeP (1:7189)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-QtF.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetails77d (1:7160)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801Ru1 (1:7164)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame298049q1 (1:7165)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // ralphedwardssm1 (1:7166)
                                                          'Ralph Edwards',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolorCYP (1:7167)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800vjH (1:7168)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001qrF (1:7169)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-vkF.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005xfy (1:7172)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-us5.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006VR1 (1:7175)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-kV5.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50072A3 (1:7178)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-APh.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1MTD (1:7181)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-sbD.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle1ti3 (1:7161)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-oQb.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsp5u (1:7251)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 16*fem),
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroup7ihujif (XTyhddbnghY6K9fdTS7ihu)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photog87 (1:7281)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-Vn7.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779ysu (1:7286)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-h9R.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsb8b (1:7257)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801WmM (1:7261)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804Suu (1:7262)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    height: 39*fem,
                                                    child: Stack(
                                                      children: [
                                                        Positioned(
                                                          // courtneyhenryyuq (1:7263)
                                                          left: 0*fem,
                                                          top: 0*fem,
                                                          child: Align(
                                                            child: SizedBox(
                                                              width: 111*fem,
                                                              height: 21*fem,
                                                              child: Text(
                                                                'Courtney Henry',
                                                                style: SafeGoogleFont (
                                                                  'Poppins',
                                                                  fontSize: 14*ffem,
                                                                  fontWeight: FontWeight.w500,
                                                                  height: 1.5*ffem/fem,
                                                                  color: Color(0xff000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          // loremipsumdolorsitametdolorskK (1:7264)
                                                          left: 0*fem,
                                                          top: 20.9997558594*fem,
                                                          child: Align(
                                                            child: SizedBox(
                                                              width: 207*fem,
                                                              height: 18*fem,
                                                              child: Text(
                                                                'lorem ipsum dolor sit amet dolor ...',
                                                                style: SafeGoogleFont (
                                                                  'Poppins',
                                                                  fontSize: 12*ffem,
                                                                  fontWeight: FontWeight.w400,
                                                                  height: 1.5*ffem/fem,
                                                                  color: Color(0xff000000),
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800AUX (1:7265)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001HJF (1:7266)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-CDu.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple50051EF (1:7269)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-QwH.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006iPZ (1:7272)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-trs.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007SKZ (1:7275)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-hGB.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1NDD (1:7278)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-wTD.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle17Ao (1:7258)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-AAK.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // trainerdetailsRhH (1:7348)
                                  width: double.infinity,
                                  height: 92*fem,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // autogroupqyatyio (XTyiEs65iomrHnX8xbQYaT)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 0*fem),
                                        width: 64*fem,
                                        height: double.infinity,
                                        child: TextButton(
                                          // photo85u (1:7378)
                                          onPressed: () {},
                                          style: TextButton.styleFrom (
                                            padding: EdgeInsets.zero,
                                          ),
                                          child: Container(
                                            padding: EdgeInsets.fromLTRB(27.52*fem, 81.76*fem, 27.52*fem, 0*fem),
                                            width: double.infinity,
                                            height: double.infinity,
                                            decoration: BoxDecoration (
                                              image: DecorationImage (
                                                fit: BoxFit.cover,
                                                image: AssetImage (
                                                  'assets/page-1/images/ellipse-800-x5V.png',
                                                ),
                                              ),
                                            ),
                                            child: Align(
                                              // group29779Rqh (1:7383)
                                              alignment: Alignment.bottomCenter,
                                              child: SizedBox(
                                                width: 8.96*fem,
                                                height: 10.24*fem,
                                                child: Image.asset(
                                                  'assets/page-1/images/group-29779-kET.png',
                                                  width: 8.96*fem,
                                                  height: 10.24*fem,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        // userdetailsdRy (1:7354)
                                        margin: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 16*fem),
                                        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                                        height: double.infinity,
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // frame29801jju (1:7358)
                                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 42*fem, 0*fem),
                                              width: 207*fem,
                                              height: double.infinity,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Container(
                                                    // frame29804sLK (1:7359)
                                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                                                    width: double.infinity,
                                                    child: Column(
                                                      crossAxisAlignment: CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          // janecooperoUs (1:7360)
                                                          'Jane Cooper',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 14*ffem,
                                                            fontWeight: FontWeight.w500,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                        Text(
                                                          // loremipsumdolorsitametdolor9Hq (1:7361)
                                                          'lorem ipsum dolor sit amet dolor ...',
                                                          style: SafeGoogleFont (
                                                            'Poppins',
                                                            fontSize: 12*ffem,
                                                            fontWeight: FontWeight.w400,
                                                            height: 1.5*ffem/fem,
                                                            color: Color(0xff000000),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  Container(
                                                    // frame29800Uqu (1:7362)
                                                    padding: EdgeInsets.fromLTRB(1.33*fem, 1.33*fem, 1.33*fem, 2*fem),
                                                    height: 16*fem,
                                                    child: Row(
                                                      crossAxisAlignment: CrossAxisAlignment.center,
                                                      children: [
                                                        Container(
                                                          // starpurple5001oNP (1:7363)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-1-CDu-AgX.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5005Wnb (1:7366)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-5-aAb.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5006eP1 (1:7369)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-6-QB9.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starpurple5007UN3 (1:7372)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starpurple500-7-7g3.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 6.67*fem,
                                                        ),
                                                        Container(
                                                          // starborder1zLP (1:7375)
                                                          width: 13.33*fem,
                                                          height: 12.67*fem,
                                                          child: Image.asset(
                                                            'assets/page-1/images/starborder-1-JeB.png',
                                                            width: 13.33*fem,
                                                            height: 12.67*fem,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Container(
                                              // addcircle18Bh (1:7355)
                                              margin: EdgeInsets.fromLTRB(0*fem, 5*fem, 0*fem, 0*fem),
                                              width: 20*fem,
                                              height: 20*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/addcircle-1-ZXm.png',
                                                width: 20*fem,
                                                height: 20*fem,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // homeindicatorSiB (1:7455)
                    left: 0*fem,
                    top: 432*fem,
                    child: Container(
                      padding: EdgeInsets.fromLTRB(121*fem, 21*fem, 120*fem, 8*fem),
                      width: 375*fem,
                      height: 34*fem,
                      decoration: BoxDecoration (
                        color: Color(0xffffffff),
                      ),
                      child: Center(
                        // homeindicatorYmD (I1:7455;5:3093)
                        child: SizedBox(
                          width: double.infinity,
                          height: 5*fem,
                          child: Container(
                            decoration: BoxDecoration (
                              borderRadius: BorderRadius.circular(100*fem),
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}